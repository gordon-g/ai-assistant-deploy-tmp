#!/bin/bash
# 精准营养 AI 助手 · 服务器一键部署脚本
# 用法：在服务器上项目根目录执行  bash deploy.sh
# 前提：已安装 python3 + pip3；本脚本会自动装依赖并用 systemd 注册为常驻服务。

set -e

APP_NAME="precision-nutrition-assistant"
PORT="8000"
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
PY="python3"

echo "=============================================="
echo "  精准营养 AI 助手 · 服务器部署"
echo "  项目目录: $BASE_DIR"
echo "=============================================="

# 1. 检查 python3
if ! command -v $PY >/dev/null 2>&1; then
  echo "[错误] 未检测到 python3，请先安装：sudo apt install -y python3 python3-pip"
  exit 1
fi

# 2. 安装依赖
echo "[1/4] 安装 Python 依赖..."
$PY -m pip install --upgrade pip >/dev/null 2>&1 || true
$PY -m pip install -r "$BASE_DIR/requirements.txt"

# 3. 检查关键配置
echo "[2/4] 检查配置..."
if ! $PY -c "import json; c=json.load(open('$BASE_DIR/config.json')); k=c['llm']['api_key']; assert k and k not in ('YOUR_API_KEY_HERE','在此填写你的APIKey'), '未填写 api_key'; print('云端模型已配置:', c['llm']['model'])" ; then
  echo "[警告] 云端模型 API Key 未配置！"
  echo "        请编辑 $BASE_DIR/config.json 的 llm.api_key 后重新执行本脚本。"
  echo "        （不填也能启动，但会降级到本地 Ollama / 知识库原文）"
fi

# 4. 生成 systemd 服务
echo "[3/4] 注册 systemd 常驻服务..."
SERVICE_FILE="/etc/systemd/system/${APP_NAME}.service"
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Precision Nutrition AI Assistant
After=network.target

[Service]
Type=simple
WorkingDirectory=${BASE_DIR}/backend
ExecStart=${PY} -m uvicorn app:app --host 0.0.0.0 --port ${PORT}
Restart=always
RestartSec=3
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$APP_NAME" >/dev/null 2>&1 || true
systemctl restart "$APP_NAME"

# 5. 自检
echo "[4/4] 自检..."
sleep 3
if curl -s "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
  echo ""
  echo "✅ 部署成功！服务已启动。"
  echo "   健康检查: curl http://127.0.0.1:${PORT}/api/health"
  echo "   访问页面: http://<服务器公网IP>:${PORT}"
  echo "   拦截规则管理: http://<服务器公网IP>:${PORT}/guard"
  echo ""
  echo "   常用命令："
  echo "     查看状态: systemctl status ${APP_NAME}"
  echo "     查看日志: journalctl -u ${APP_NAME} -f"
  echo "     重启服务: systemctl restart ${APP_NAME}"
else
  echo ""
  echo "⚠️  服务可能未正常启动，请查看日志："
  echo "   journalctl -u ${APP_NAME} -n 50 --no-pager"
fi
