/**
 * 4P 精准营养方案解读助手 —— 站内嵌入脚本（embed.js）
 *
 * 用法：在 4Pwellness.org.cn 登录后的页面里，把下面两行放到 </body> 前即可：
 *
 *   <div id="p4-ai-widget"></div>
 *   <script src="https://你的部署域名/static/embed.js" data-launch="点我咨询营养方案"></script>
 *
 * 说明：
 * - 通过 data-launch 指定触发按钮文案；也可用 data-auto="true" 让浮窗自动打开。
 * - 脚本会创建一个可拖动、可最小化、可关闭的浮窗，内部 iframe 加载 widget.html。
 * - 关闭时通过 postMessage 通信；iframe 内点关闭会通知本脚本隐藏浮窗。
 */
(function () {
  var SCRIPT = document.currentScript;
  var BASE = SCRIPT ? new URL(SCRIPT.src).origin : window.location.origin;
  var LAUNCH_TEXT = (SCRIPT && SCRIPT.getAttribute('data-launch')) || '🌿 营养方案解读助手';
  var AUTO = (SCRIPT && SCRIPT.getAttribute('data-auto')) === 'true';

  // 避免重复注入
  if (window.__p4WidgetInjected) return;
  window.__p4WidgetInjected = true;

  function injectStyle() {
    var css = [
      '#p4-widget-launch{position:fixed;right:20px;bottom:24px;z-index:99999;background:#2f7d5d;color:#fff;border:none;border-radius:24px;padding:12px 20px;font-size:14px;font-weight:600;cursor:pointer;box-shadow:0 4px 20px rgba(47,125,93,.35);font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;}',
      '#p4-widget-launch:hover{background:#245f47;}',
      '#p4-widget-frame{position:fixed;right:20px;bottom:80px;width:400px;height:600px;max-width:calc(100vw - 20px);max-height:calc(100vh - 100px);z-index:99998;border:1px solid #e5e7eb;border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,.18);background:#fff;display:none;}',
      '#p4-widget-frame.show{display:block;}',
      '#p4-widget-frame iframe{width:100%;height:100%;border:none;border-radius:16px;}',
      '@media (max-width:480px){#p4-widget-frame{width:100vw;height:100vh;max-width:100vw;max-height:100vh;right:0;bottom:0;border-radius:0;}}'
    ].join('\n');
    var s = document.createElement('style');
    s.textContent = css;
    document.head.appendChild(s);
  }

  function createUI() {
    // 触发按钮
    var btn = document.createElement('button');
    btn.id = 'p4-widget-launch';
    btn.textContent = LAUNCH_TEXT;
    btn.onclick = function () {
      frame.classList.toggle('show');
      if (!loaded) { iframe.src = BASE + '/static/widget.html'; loaded = true; }
    };
    document.body.appendChild(btn);

    // 浮窗容器
    var frame = document.createElement('div');
    frame.id = 'p4-widget-frame';
    var iframe = document.createElement('iframe');
    iframe.setAttribute('allow', 'clipboard-read; clipboard-write');
    frame.appendChild(iframe);
    document.body.appendChild(frame);
    var loaded = false;

    if (AUTO) {
      frame.classList.add('show');
      iframe.src = BASE + '/static/widget.html';
      loaded = true;
    }
  }

  function listenClose() {
    window.addEventListener('message', function (e) {
      if (e.data && e.data.type === '4p-widget-close') {
        var f = document.getElementById('p4-widget-frame');
        if (f) f.classList.remove('show');
      }
    });
  }

  injectStyle();
  createUI();
  listenClose();
})();
