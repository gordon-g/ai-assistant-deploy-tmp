#!/bin/bash
# ============================================================
#  原地升级脚本（v2 · 2026-11-04）
#  用途：把服务器上的旧版后端替换为最新版（含 136 成分白名单 + 打分式检索闸门）
#  特点：不重装系统、不动 Nginx 站点、自动探测目录与端口、失败可一键回滚
#
#  用法（在服务器上、解压后的目录里执行）：
#     bash upgrade.sh
#
#  可选环境变量：
#     APP_DIR=/opt/xxx    # 应用目录（默认自动探测）
#     PORT=8000           # 后端端口（默认自动探测）
#     YES=1               # 跳过确认
# ============================================================

set -uo pipefail
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok(){   echo -e "${GREEN}✅ $1${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $1${NC}"; }
err(){  echo -e "${RED}❌ $1${NC}"; }
info(){ echo -e "${CYAN}   $1${NC}"; }

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP=$(date +%Y%m%d_%H%M%S)

echo "=================================================="
echo "  4P 精准营养 AI 助手 · 原地升级 v2"
echo "  源目录: $SRC_DIR"
echo "  时间  : $(date '+%F %T')"
echo "=================================================="

# ---------------- 1. 探测应用目录 ----------------
echo ""
echo "[1/7] 探测现有部署..."
APP_DIR="${APP_DIR:-}"

if [ -z "$APP_DIR" ]; then
  PID=$(pgrep -f "uvicorn app:app" | head -1 || true)
  if [ -n "$PID" ]; then
    CWD=$(readlink -f "/proc/$PID/cwd" 2>/dev/null || true)
    APP_DIR=$(echo "$CWD" | sed 's#/backend$##')
    [ -n "$APP_DIR" ] && info "从运行进程探测到: $APP_DIR (PID=$PID)"
  fi
fi

if [ -z "$APP_DIR" ] || [ ! -f "$APP_DIR/backend/app.py" ]; then
  APP_DIR=""
  for d in /opt/precision-nutrition-assistant /opt/precision-nutrition /opt/ai-assistant \
           /root/ai-assistant /www/ai-assistant /var/www/ai-assistant /srv/ai-assistant \
           /data/ai-assistant /home/*/ai-assistant; do
    if [ -f "$d/backend/app.py" ]; then APP_DIR="$d"; break; fi
  done
fi

if [ -z "$APP_DIR" ]; then
  warn "未能自动定位旧应用目录，请手动指定："
  echo "     APP_DIR=/你的旧目录 bash upgrade.sh"
  echo ""
  echo "  快速定位："
  echo "     pgrep -af 'uvicorn app:app'"
  echo "     ls -d /opt/*ai* /root/*ai* 2>/dev/null"
  exit 1
fi
ok "应用目录: $APP_DIR"

# ---------------- 2. 探测端口 ----------------
echo ""
echo "[2/7] 探测后端端口..."
PORT="${PORT:-}"
if [ -z "$PORT" ]; then
  # (a) 运行中进程的命令行
  PORT=$(pgrep -af "uvicorn" 2>/dev/null | grep -oE -- "--port[= ]+[0-9]+" | grep -oE "[0-9]+" | head -1 || true)
  [ -n "$PORT" ] && info "从进程参数探测到端口: $PORT"
fi
if [ -z "$PORT" ]; then
  # (b) Nginx 反代配置
  PORT=$(grep -rhoE "proxy_pass\s+https?://(127\.0\.0\.1|localhost):[0-9]+" /etc/nginx/ 2>/dev/null \
         | grep -oE "[0-9]+$" | sort -u | head -1 || true)
  [ -n "$PORT" ] && info "从 Nginx 反代探测到端口: $PORT"
fi
if [ -z "$PORT" ]; then
  # (c) 逐个探活
  for p in 8000 8901 8902 8903 8904 8905 8906 8907 8080 5000; do
    if curl -s -m 1 "http://127.0.0.1:$p/api/health" >/dev/null 2>&1; then
      PORT=$p; info "探活发现端口: $PORT"; break
    fi
  done
fi
if [ -z "$PORT" ]; then
  PORT=8000
  warn "未探测到端口，默认使用 8000（如不对请用 PORT=xxxx bash upgrade.sh 重跑）"
fi
ok "后端端口: $PORT"

# ---------------- 3. 备份 ----------------
echo ""
echo "[3/7] 备份旧版本..."
BAK="${APP_DIR}.bak.${STAMP}"
cp -a "$APP_DIR" "$BAK" && ok "已备份到: $BAK" || { err "备份失败，中止（未做任何修改）"; exit 1; }

# ---------------- 4. 记录旧配置 ----------------
OLD_CFG="$APP_DIR/config.json"
KEY_BACKUP=""
if [ -f "$OLD_CFG" ]; then
  KEY_BACKUP=$(python3 -c "import json;print(json.load(open('$OLD_CFG'))['llm'].get('api_key',''))" 2>/dev/null || echo "")
  cp -a "$OLD_CFG" "$BAK/config.json.orig" 2>/dev/null || true
fi

# ---------------- 5. 替换文件 ----------------
echo ""
echo "[4/7] 替换为最新版..."
for item in backend frontend data config.json requirements.txt start.sh deploy.sh install.sh 话术库 02_人设提示词V3_可直接粘贴.md 客户话术样板_V1.0.md; do
  if [ -e "$SRC_DIR/$item" ]; then
    rm -rf "${APP_DIR:?}/$item"
    cp -a "$SRC_DIR/$item" "$APP_DIR/$item"
  fi
done
find "$APP_DIR" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$APP_DIR" -name "*.pyc" -delete 2>/dev/null || true
ok "文件已替换"

# ---------------- 6. 恢复 Key + 依赖 ----------------
echo ""
echo "[5/7] 恢复配置并安装依赖..."
if [ -n "$KEY_BACKUP" ] && [ "$KEY_BACKUP" != "YOUR_API_KEY_HERE" ]; then
  python3 - "$APP_DIR/config.json" "$KEY_BACKUP" <<'PY'
import json,sys
p,k=sys.argv[1],sys.argv[2]
c=json.load(open(p)); c.setdefault('llm',{})['api_key']=k
json.dump(c,open(p,'w'),ensure_ascii=False,indent=2)
PY
  ok "已保留原有 API Key"
else
  warn "未发现已配置的 Key —— 升级后模型不可用，只会回知识缺口话术"
  info "填 Key：nano $APP_DIR/config.json → llm.api_key"
fi

python3 -m pip install -q -r "$APP_DIR/requirements.txt" 2>/dev/null \
  || python3 -m pip install -q --break-system-packages -r "$APP_DIR/requirements.txt" 2>/dev/null \
  || warn "依赖安装有告警，若启动失败请手动 pip install -r requirements.txt"
ok "依赖就绪"

# ---------------- 7. 重启 ----------------
echo ""
echo "[6/7] 重启服务..."
# 找监听该端口的进程 → 反查 systemd 单元 → 否则当裸进程处理
LISTEN_PID=$(ss -lptnH "sport = :$PORT" 2>/dev/null | grep -oE 'pid=[0-9]+' | head -1 | cut -d= -f2 || true)
SERVICE=""
if [ -n "$LISTEN_PID" ]; then
  SERVICE=$(systemctl status "$LISTEN_PID" 2>/dev/null | grep -oE '[a-zA-Z0-9_.@-]+\.service' | head -1 || true)
fi
if [ -z "$SERVICE" ]; then
  SERVICE=$(systemctl list-units --type=service --all 2>/dev/null \
            | grep -iE "precision|nutrition|assistant|uvicorn|ai" | awk '{print $1}' | head -1 || true)
fi

if [ -n "$SERVICE" ]; then
  info "systemd 服务: $SERVICE"
  systemctl restart "$SERVICE" && ok "服务已重启" || {
    warn "systemctl restart 失败，改按裸进程重启"
    SERVICE=""
  }
fi

if [ -z "$SERVICE" ]; then
  if [ -n "$LISTEN_PID" ]; then
    info "终止旧进程 PID=$LISTEN_PID"
    kill "$LISTEN_PID" 2>/dev/null || true; sleep 2
    kill -9 "$LISTEN_PID" 2>/dev/null || true
  fi
  pkill -f "uvicorn app:app" 2>/dev/null || true
  sleep 1
  ( cd "$APP_DIR/backend" && setsid nohup python3 -m uvicorn app:app --host 0.0.0.0 --port "$PORT" \
      > "$APP_DIR/app.log" 2>&1 < /dev/null & )
  sleep 3
  ok "已按裸进程重启（日志: $APP_DIR/app.log）"
fi

# ---------------- 自检 + 回归 ----------------
echo ""
echo "[7/7] 自检与回归..."
FAIL=0
for i in 1 2 3 4 5 6 7 8; do
  if curl -s -m 8 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then break; fi
  sleep 2
done

H=$(curl -s -m 8 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null || echo "")
if [ -z "$H" ]; then
  err "新服务未响应，最近日志："
  if [ -n "$SERVICE" ]; then journalctl -u "$SERVICE" -n 30 --no-pager; else tail -30 "$APP_DIR/app.log" 2>/dev/null; fi
  echo ""
  echo "  回滚：rm -rf $APP_DIR && mv $BAK $APP_DIR && systemctl restart ${SERVICE:-<你的服务名>}"
  exit 1
fi

ask(){  # ask <标签> <json> <期望片段>
  local label="$1" body="$2" expect="$3" resp
  resp=$(curl -s -m 40 -X POST "http://127.0.0.1:${PORT}/api/ask" \
    -H "Content-Type: application/json" -d "$body" 2>/dev/null || echo "")
  if [ -z "$resp" ]; then echo -e "${YELLOW}⚠️  $label : 无响应${NC}"; FAIL=$((FAIL+1)); return; fi
  if echo "$resp" | grep -Eq "$expect"; then ok "$label : 通过"
  else echo -e "${RED}❌ $label : 未命中期望「$expect」${NC}"; echo "$resp" | head -c 300; echo; FAIL=$((FAIL+1)); fi
}

info "健康检查: $H"
echo ""
echo "  — 拦截回归 —"
ask "闲聊拦截"     '{"question":"今天天气怎么样"}'                     '"blocked"\s*:\s*true'
ask "红线拦截"     '{"question":"这个产品能治好糖尿病吗"}'             '"blocked"\s*:\s*true'
ask "身份询问"     '{"question":"你是谁"}'                             '"blocked"\s*:\s*true'
ask "算术拦截"     '{"question":"23乘以17等于多少"}'                   '"blocked"\s*:\s*true'

echo ""
echo "=================================================="
if [ "$FAIL" -eq 0 ]; then
  ok "升级完成，回归全部通过"
else
  warn "升级完成，但有 $FAIL 项回归未通过（服务已起，属话术/检索层问题，可继续观察）"
fi
echo "=================================================="
ok "版本: 136 成分白名单 + 打分式检索闸门 + 五类出口"
info "备份: $BAK"
info "回滚: rm -rf $APP_DIR && mv $BAK $APP_DIR && systemctl restart ${SERVICE:-<服务名>}"
echo ""
if echo "$H" | grep -q '"ok":true'; then
  ok "模型通道正常"
else
  warn "模型通道不通 —— 客户问知识库里有的业务问题时，只会回复「知识缺口」话术"
  info "两种解法："
  info "  A. 填混元 Key（推荐，免费额度）：nano $APP_DIR/config.json → llm.api_key"
  info "  B. 服务器上装 Ollama 并拉 qwen3:8b（占内存 8G+，轻量服务器通常不够）"
fi
