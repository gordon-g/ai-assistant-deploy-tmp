#!/usr/bin/env bash
# ============================================================
# 精准营养 AI 助手 · 一键启动脚本
# 用法：
#   Mac/Linux:   bash start.sh
#   Windows:     用 start.bat（同目录下的另一个文件）
#
# 它会自动：装依赖 → 检查 Ollama → 启动后端 → 打开浏览器
# ============================================================

set -e
cd "$(dirname "$0")"

echo "=============================================="
echo "  精准营养 AI 助手 · 一键启动"
echo "=============================================="

# 1. 检查 Python
if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ 未检测到 python3，请先安装 Python 3.9+"
  echo "   下载地址：https://www.python.org/downloads/"
  exit 1
fi
echo "✅ Python: $(python3 --version)"

# 2. 安装依赖（静默，已装则跳过）
echo "📦 正在检查依赖…"
python3 -m pip install -q fastapi uvicorn requests pypdf 2>/dev/null || \
  python3 -m pip install --user -q fastapi uvicorn requests pypdf

# 3. 检查 Ollama（不强制，没有也能用降级模式）
echo "🔍 检查本地 Ollama…"
if curl -s -m 2 http://localhost:11434/api/tags >/dev/null 2>&1; then
  echo "✅ Ollama 已连接"
  MODELS=$(curl -s http://localhost:11434/api/tags | python3 -c "import sys,json; print(', '.join(m['name'] for m in json.load(sys.stdin).get('models',[])))" 2>/dev/null)
  if [ -n "$MODELS" ]; then
    echo "   已加载模型：$MODELS"
    echo "   👉 请确认上面有你要用的模型（默认 qwen3:8b）"
    echo "      若没有，另开终端运行：ollama pull qwen3:8b"
  else
    echo "   ⚠️  Ollama 在线，但还没有任何模型"
    echo "      请先运行：ollama pull qwen3:8b  （约5.2GB，下载一次即可）"
  fi
else
  echo "⚠️  未检测到 Ollama"
  echo "   请先打开 Ollama 桌面应用（羊驼图标），再重新运行本脚本"
  echo "   若已打开，可能是应用还在启动中，等几秒再试"
fi

# 4. 启动后端
echo "🚀 正在启动后端服务（端口 8000）…"
echo "   浏览器会自动打开，如未打开请手动访问 http://localhost:8000"
echo "   按 Ctrl+C 可停止服务"
echo "=============================================="

# 自动打开浏览器（跨平台）
(sleep 2; \
  command -v open >/dev/null 2>&1 && open http://localhost:8000; \
  command -v xdg-open >/dev/null 2>&1 && xdg-open http://localhost:8000; \
  true) &

# 启动（前台运行，Ctrl+C 停止）
cd backend
python3 app.py
