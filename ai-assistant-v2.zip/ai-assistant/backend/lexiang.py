# -*- coding: utf-8 -*-
"""知识库检索：支持两种模式。

模式1 local：内置知识库（默认），从 data/knowledge/*.md 读取，做简单的关键词/语义匹配。
模式2 api：调用乐享官方 API（向量检索），需要 AppKey/AppSecret 换 access_token。

这样先保证流程能跑通，拿到凭证后一行配置即可切到真乐享。
"""
import json
import re
from pathlib import Path
import requests

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
KNOWLEDGE_DIR = DATA_DIR / "knowledge"


class LocalKnowledgeBase:
    """内置知识库：加载 data/knowledge 下的 md 文档，做关键词召回。"""

    def __init__(self):
        self.docs = []  # [{'title':str, 'content':str, 'tags':str}, ...]
        self._load()

    def _load(self):
        if not KNOWLEDGE_DIR.exists():
            return
        for f in sorted(KNOWLEDGE_DIR.glob("*.md")):
            text = f.read_text(encoding="utf-8")
            title = f.stem
            content = text
            # 提取标签行
            tags = ""
            for line in text.splitlines():
                if line.strip().startswith(">"):
                    tags += line.strip().lstrip("> ").strip() + " "
            self.docs.append({"title": title, "content": content, "tags": tags.strip()})

    def search(self, query, top_k=3):
        """关键词召回：按命中次数打分，返回 top_k 条。"""
        if not self.docs:
            return []
        # 简单分词（按常见分隔符切）
        q_terms = [t for t in re.split(r"[\s,，。、/\\|；;：:？?!！\u3000]+", query) if len(t) >= 2]
        scored = []
        for doc in self.docs:
            haystack = doc["title"] + " " + doc["tags"] + " " + doc["content"]
            score = 0
            for term in q_terms:
                if term in haystack:
                    score += 1
            # 标题命中加权
            if any(t in doc["title"] for t in q_terms):
                score += 3
            if score > 0:
                scored.append((score, doc))
        scored.sort(key=lambda x: -x[0])
        return [d for _, d in scored[:top_k]]


class LexiangAPI:
    """乐享官方 API 检索（AI 搜索接口）。"""

    def __init__(self, app_key, app_secret, space_id, token_url,
                 ai_search_url=None, staff_id="LX001", targets=None):
        self.app_key = app_key
        self.app_secret = app_secret
        self.space_id = space_id
        self.token_url = token_url
        self.ai_search_url = ai_search_url or "https://lxapi.lexiangla.com/cgi-bin/v1/ai/search"
        self.staff_id = staff_id
        # targets：检索范围，默认整个空间；也可精确到某个 entry（如靶点识别知识库容器）
        self.targets = targets or [{"type": "space", "id": space_id}]
        self._token = None

    def _get_token(self):
        if self._token:
            return self._token
        r = requests.post(self.token_url, json={
            "grant_type": "client_credentials",
            "app_key": self.app_key,
            "app_secret": self.app_secret,
        }, timeout=10)
        r.raise_for_status()
        self._token = r.json()["access_token"]
        return self._token

    def search(self, query, top_k=3):
        """调用乐享 AI 搜索接口（语义检索）。"""
        token = self._get_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "x-staff-id": self.staff_id,
            "Content-Type": "application/json; charset=utf-8",
        }
        payload = {
            "query": query,
            "targets": self.targets,
            "top_n": max(top_k, 1),
        }
        r = requests.post(self.ai_search_url, json=payload, headers=headers, timeout=30)
        r.raise_for_status()
        data = r.json()
        # 归一化返回，与 LocalKnowledgeBase.search 保持同结构
        results = []
        seen_titles = set()
        for item in data.get("data", {}).get("list", []):
            title = item.get("title", "")
            # 去重：同一文档可能返回多个片段
            if title in seen_titles:
                continue
            seen_titles.add(title)
            content = item.get("content", "") or ""
            results.append({
                "title": title,
                "content": content,
                "url": item.get("url", ""),   # 来源链接（前端可跳转）
                "tags": "",
            })
            if len(results) >= top_k:
                break
        return results


class KnowledgeBase:
    """统一检索入口，根据 config 自动选择模式。"""

    def __init__(self, config):
        mode = config.get("mode", "local")
        if mode == "api" and config.get("app_key") and config.get("app_secret"):
            self.backend = LexiangAPI(
                config["app_key"], config["app_secret"],
                config.get("space_id", ""), config.get("token_url", ""),
                ai_search_url=config.get("ai_search_url"),
                staff_id=config.get("staff_id", "LX001"),
                targets=config.get("targets"),
            )
            self.mode = "api"
        else:
            self.backend = LocalKnowledgeBase()
            self.mode = "local"

    def search(self, query, top_k=3):
        return self.backend.search(query, top_k=top_k)
