# -*- coding: utf-8 -*-
"""云端大模型客户端（OpenAI 兼容接口）。

支持腾讯混元、通义千问、DeepSeek 等几乎所有提供 OpenAI 兼容 /chat/completions 接口的厂商。
配置在 config.json 的 "llm" 块，provider 决定默认 base_url，也可手动指定 base_url 覆盖。

用法：
    from cloud_llm import CloudLLM
    llm = CloudLLM(config["llm"])
    text = llm.chat(messages)            # 非流式
    for piece in llm.chat_stream(messages):  # 流式
        ...
"""
import json
import requests


# 各厂商默认的 OpenAI 兼容 endpoint 与默认模型（用户可覆盖）
PROVIDERS = {
    "hunyuan": {
        "name": "腾讯混元",
        "base_url": "https://api.hunyuan.cloud.tencent.com/v1",
        "default_model": "hunyuan-turbos-latest",
    },
    "qwen": {
        "name": "通义千问",
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "default_model": "qwen-plus",
    },
    "deepseek": {
        "name": "DeepSeek",
        "base_url": "https://api.deepseek.com/v1",
        "default_model": "deepseek-chat",
    },
    "openai": {
        "name": "OpenAI",
        "base_url": "https://api.openai.com/v1",
        "default_model": "gpt-4o-mini",
    },
}


class CloudLLM:
    def __init__(self, cfg):
        self.provider = cfg.get("provider", "hunyuan")
        p = PROVIDERS.get(self.provider, {})
        self.base_url = (cfg.get("base_url") or p.get("base_url", "")).rstrip("/")
        self.model = cfg.get("model") or p.get("default_model", "")
        self.api_key = cfg.get("api_key", "")
        self.temperature = cfg.get("temperature", 0.7)
        self.max_tokens = cfg.get("max_tokens", 2048)
        self._last_error = ""

    # ---------- 状态 ----------
    @property
    def configured(self):
        """是否已配置 API Key（空则视为未配置）。"""
        return bool(self.api_key) and self.api_key not in ("", "YOUR_API_KEY_HERE", "在此填写你的APIKey")

    def health(self):
        """返回 (ok, message)。不真正发请求，只判断配置是否就绪。"""
        if not self.base_url:
            return False, "未配置 base_url"
        if not self.model:
            return False, "未配置 model"
        if not self.configured:
            return False, "未配置 API Key（请在 config.json 的 llm.api_key 填写）"
        return True, f"云端模型 {self.provider}({self.model}) 配置就绪"

    # ---------- 对话 ----------
    def _build_payload(self, messages, stream):
        return {
            "model": self.model,
            "messages": messages,
            "stream": stream,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

    def _headers(self):
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    def chat(self, messages):
        """非流式对话。messages 为标准 OpenAI 格式（system 已在 messages 内）。"""
        payload = self._build_payload(messages, stream=False)
        r = requests.post(
            f"{self.base_url}/chat/completions",
            headers=self._headers(),
            json=payload,
            timeout=300,
        )
        if r.status_code != 200:
            self._last_error = f"HTTP {r.status_code}: {r.text[:300]}"
            raise RuntimeError(self._last_error)
        data = r.json()
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            self._last_error = f"响应格式异常：{json.dumps(data, ensure_ascii=False)[:300]}"
            raise RuntimeError(self._last_error)

    def chat_stream(self, messages):
        """流式对话，逐段 yield 文本。"""
        payload = self._build_payload(messages, stream=True)
        with requests.post(
            f"{self.base_url}/chat/completions",
            headers=self._headers(),
            json=payload,
            stream=True,
            timeout=600,
        ) as r:
            if r.status_code != 200:
                body = r.text[:300]
                self._last_error = f"HTTP {r.status_code}: {body}"
                raise RuntimeError(self._last_error)
            for raw in r.iter_lines(decode_unicode=True):
                if not raw or not raw.startswith("data:"):
                    continue
                data = raw[len("data:"):].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except json.JSONDecodeError:
                    continue
                try:
                    delta = obj["choices"][0].get("delta", {})
                    piece = delta.get("content", "")
                except (KeyError, IndexError):
                    continue
                if piece:
                    yield piece
