# -*- coding: utf-8 -*-
"""精准营养干预方案 PDF 解析器。

从用户上传的《精准营养干预方案》PDF 中提取结构化信息，供 AI 助手
从「靶点分析 / 配方解读 / 方案整合 / 效果评价」四个维度进行解读。

报告九章结构：
  一 用户基本信息
  二 方案概述（含 5 分钟速读指南）
  三 健康风险评估（24 维度，风险五级）
  四 历史数据对比
  五 精准营养配方建议（成分 + 剂量 + 服用方式）
  六 干预路径解读（按健康维度解释成分配伍依据）
  七 生活方式建议
  八 常见问答
  九 免责声明
"""
import re
from io import BytesIO


def extract_pdf_text(file_bytes: bytes) -> str:
    """用 pypdf 提取 PDF 全文。"""
    from pypdf import PdfReader
    reader = PdfReader(BytesIO(file_bytes))
    pages = []
    for i, page in enumerate(reader.pages):
        try:
            t = page.extract_text() or ""
        except Exception:
            t = ""
        pages.append(f"===== 第{i+1}页 =====\n{t}")
    return "\n".join(pages)


# ---- 风险等级关键词 → 归一化 ----
RISK_LEVELS = ["危险期", "高风险", "中风险", "低风险", "理想区间", "数据缺失", "无风险"]

# 24 个健康维度（用于从风险评估章节中定位）
HEALTH_DIMENSIONS = [
    "血压", "血糖", "胆固醇-血脂", "甘油三酯-血脂", "尿酸", "同型半胱氨酸",
    "维生素D", "贫血", "甲状腺", "肝功能", "肾功能", "心脏功能",
    "上消化道", "消化不良", "便秘", "腹泻", "压力", "疲劳", "免疫",
    "骨关节功能", "骨密度", "眼睛健康", "大脑健康", "睡眠质量", "前列腺增生",
]


def _pick(text, *patterns, group=0, default=""):
    """按顺序尝试多个正则，返回第一个命中的捕获组。"""
    for p in patterns:
        m = re.search(p, text, flags=re.S)
        if m:
            try:
                return m.group(group).strip()
            except IndexError:
                return m.group(0).strip()
    return default


def _clean_field(v, *labels):
    """去掉字段值前面误带的标签（如 '姓名/ID 韩立军/112547' → '韩立军/112547'）。"""
    v = v.strip()
    for lb in labels:
        # 形如 "姓名/ID 韩立军" 或 "年龄 36" 或 "BMI 24.49"
        v = re.sub(rf"^{re.escape(lb)}[\s/:：]*", "", v)
    return v.strip()


def parse_report(file_bytes: bytes) -> dict:
    """解析 PDF，返回结构化字典。"""
    full = extract_pdf_text(file_bytes)
    result = {
        "filename": "",
        "user_info": {},
        "risk_assessment": {},
        "risk_levels": [],
        "focus_risks": [],
        "formula": {},
        "ingredients": [],
        "intervention_paths": [],
        "lifestyle": "",
        "history_compare": "",
        "raw_text": full,
    }

    # 一：用户基本信息
    name = _clean_field(_pick(full, r"姓名/ID\s*([^\n]+)", r"姓名\s*[:：]?\s*([^\n]+)"), "姓名/ID", "姓名")
    age = _clean_field(_pick(full, r"年龄\s*(\d+)"), "年龄")
    gender = _clean_field(_pick(full, r"性别\s*([男女])"), "性别")
    bmi = _clean_field(_pick(full, r"BMI\s*([\d.]+)"), "BMI")
    result["user_info"] = {
        "name": name or "未知",
        "age": age or "",
        "gender": gender or "",
        "bmi": bmi or "",
    }

    # 三：健康风险评估 —— 重点干预风险
    # 匹配「本方案重点干预的健康风险如下」之后的内容
    focus_m = re.search(
        r"重点干预的健康风险如下[：:]*\s*(.*?)(?:四：历史数据对比|$)",
        full, flags=re.S)
    if focus_m:
        # 提取形如 ⚠高血脂（中危）⚠肝功能中度异常 等标签
        items = re.findall(r"⚠\s*([^⚠\n]+)", focus_m.group(1))
        result["focus_risks"] = [i.strip() for i in items if i.strip()]
        # 若无 ⚠ 前缀，退化为按行拆分
        if not result["focus_risks"]:
            result["focus_risks"] = [
                l.strip() for l in focus_m.group(1).splitlines() if l.strip()]

    # 用户最希望改善的风险
    hope_m = re.search(r"最希望改善的健康风险如下[：:]*\s*(.*?)(?:\n同时|\n)", full, flags=re.S)
    if hope_m:
        result["risk_assessment"]["most_wanted"] = [
            i.strip() for i in re.findall(r"⚠\s*([^⚠\n]+)", hope_m.group(1)) if i.strip()]

    # 逐维度提取风险等级（基于「健康维度 评估内容 风险等级」表，第3-4页）
    # 表格位于「对您机体24项核心…评估如下」之后、「定性健康风险评估」之前。
    # 每个维度的风险等级紧跟在其「参考检验指标/建议补充指标」列的末尾。
    start = full.find("24项核心")
    if start == -1:
        start = full.find("健康维度 评估内容 风险等级")
    end = full.find("定性健康风险评估")
    if start != -1 and end != -1 and end > start:
        table_text = full[start:end]
    else:
        table_text = full

    # 按维度名切块：每个维度名之后到下一个维度名之间，末尾的风险等级关键词即该维度等级
    dim_positions = {}
    for dim in HEALTH_DIMENSIONS:
        # 在表格范围内找最后一次出现
        idx = table_text.rfind(dim)
        if idx != -1:
            dim_positions[dim] = idx
    ordered = sorted(dim_positions.items(), key=lambda x: x[1])

    for i, (dim, idx) in enumerate(ordered):
        nxt = ordered[i + 1][1] if i + 1 < len(ordered) else len(table_text)
        window = table_text[idx: nxt]
        # 风险等级关键词出现在该维度块的末尾
        matched = None
        for lv in RISK_LEVELS:
            if lv in window:
                matched = lv
                break
        if matched:
            result["risk_levels"].append({"dimension": dim, "level": matched})

    # 五：精准营养配方建议
    # 服用频率 / 方式 / 时间 —— 报告第11页紧凑排列：服用频率\n1杯/天服用方式\n随餐建议服用时间\n早上
    # 先定位到「服用频率」这一处（第11页），避免抓到第2页速读指南里的文字
    freq_anchor = full.find("服用频率")
    way_anchor = full.find("服用方式", freq_anchor if freq_anchor != -1 else 0)
    time_anchor = full.find("建议服用时间")

    freq = _pick(full, r"服用频率\s*([^\n]+)")
    freq = re.sub(r"服用方式.*$", "", freq).strip()
    freq = _clean_field(freq, "服用频率")
    if not freq or len(freq) > 20:
        freq = _pick(full, r"(\d+\s*杯\s*/\s*天)")

    way = _pick(full, r"服用方式\s*([^\n]+)")
    way = _clean_field(way, "服用方式")
    way = re.sub(r"建议服用时间.*$", "", way).strip()
    # 方式应为「随餐/餐前/餐后/空腹」等，若抓到别的内容则回退
    if way not in ("随餐", "餐前", "餐后", "空腹"):
        # 只在本章配方段落内找，避免抓到「空腹血糖」等无关词
        ing_section = full[full.find("五：精准营养配方建议"): full.find("六：干预路径解读")]
        m = re.search(r"(随餐|餐前|餐后|空腹)", ing_section)
        way = m.group(1) if m else way

    time_ = _pick(full, r"建议服用时间\s*([^\n]+)", r"服用时间\s*([^\n]+)")
    time_ = _clean_field(time_, "建议服用时间", "服用时间")
    tm = re.search(r"(早上|中午|晚上|睡前|晨起)", time_)
    time_ = tm.group(1) if tm else time_

    result["formula"] = {
        "frequency": freq or "",
        "way": way or "",
        "time": time_ or "",
    }

    # 成分 + 剂量：成分行形如「表没食子儿茶素没食子酸酯 80mg」，
    # 每行一个成分，成分名与剂量之间是单个空格。
    ing_section = full[full.find("五：精准营养配方建议"): full.find("六：干预路径解读")]
    # 成分行：整行 = 成分名(中文/字母/括号) + 空格 + 剂量(数字+单位)
    ing_pattern = re.compile(
        r"^([\u4e00-\u9fa5A-Za-z（）()\-·、0-9]+?)\s+(\d+(?:\.\d+)?\s*(?:mg|mcg|μg|g|IU|RAE|mmol|μmol|U)\b)\s*$",
        re.M)
    seen = set()
    for m in ing_pattern.finditer(ing_section):
        name = m.group(1).strip()
        dose = m.group(2).strip()
        key = name + dose
        if key in seen:
            continue
        seen.add(key)
        # 过滤误匹配（标题、表格字段等）
        if any(k in name for k in ("服用", "建议", "成分", "剂量", "表", "频率")):
            continue
        if len(name) > 24:
            continue
        result["ingredients"].append({"name": name, "dose": dose})

    # 六：干预路径解读 —— 按「数字. 健康维度」切块
    path_section = full[full.find("六：干预路径解读"): full.find("七：生活方式建议")]
    # 形如 "2. 胆固醇-血脂" 的分段标题
    path_blocks = re.split(r"\n(\d+\.\s*[\u4e00-\u9fa5A-Za-z\-·]+)\s*\n", path_section)
    # path_blocks: [导语, 标题1, 内容1, 标题2, 内容2, ...]
    for i in range(1, len(path_blocks) - 1, 2):
        title = path_blocks[i].strip()
        content = path_blocks[i + 1].strip() if i + 1 < len(path_blocks) else ""
        if title and content:
            result["intervention_paths"].append({
                "title": re.sub(r"^\d+\.\s*", "", title),
                "content": content,
            })

    # 七：生活方式建议
    life_m = re.search(r"七：生活方式建议\s*(.*?)(?:八：常见问答|$)", full, flags=re.S)
    if life_m:
        result["lifestyle"] = life_m.group(1).strip()

    # 四：历史数据对比
    hist_m = re.search(r"四：历史数据对比\s*(.*?)(?:五：精准营养配方建议|$)", full, flags=re.S)
    if hist_m:
        result["history_compare"] = hist_m.group(1).strip()

    return result


def _strip_page_markers(text: str) -> str:
    """去掉 PDF 分页标记和页眉页脚，得到干净正文。"""
    # 去掉「===== 第N页 =====」和「2026/8/14 精准营养干预方案」「N / 19」等
    text = re.sub(r"=====\s*第\d+\s*页\s*=====", "", text)
    text = re.sub(r"\d{4}/\d{1,2}/\d{1,2}\s*精准营养干预方案", "", text)
    text = re.sub(r"\d+\s*/\s*19\s*(?:打印)?", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def build_report_context(parsed: dict) -> str:
    """把解析结果拼成一段精简的、喂给大模型的上下文。"""
    lines = []
    ui = parsed.get("user_info", {})
    lines.append(f"【用户】{ui.get('name','')} {ui.get('gender','')} {ui.get('age','')}岁 BMI {ui.get('bmi','')}")

    if parsed.get("risk_assessment", {}).get("most_wanted"):
        lines.append("【用户最想改善】" + "、".join(parsed["risk_assessment"]["most_wanted"]))

    if parsed.get("focus_risks"):
        lines.append("【重点干预风险】" + "、".join(parsed["focus_risks"]))

    if parsed.get("risk_levels"):
        lines.append("【24维度风险分级】" + "；".join(
            f"{r['dimension']}={r['level']}" for r in parsed["risk_levels"]))

    f = parsed.get("formula", {})
    if f.get("frequency") or f.get("way") or f.get("time"):
        lines.append(f"【服用方式】{f.get('frequency','')} {f.get('way','')} {f.get('time','')}".strip())

    if parsed.get("ingredients"):
        lines.append("【配方成分】" + "、".join(
            f"{i['name']} {i['dose']}" for i in parsed["ingredients"]))

    if parsed.get("intervention_paths"):
        lines.append("【干预路径解读】")
        for p in parsed["intervention_paths"]:
            content = _strip_page_markers(p["content"])
            lines.append(f"  · {p['title']}：{content[:300]}")

    if parsed.get("lifestyle"):
        lines.append(f"【生活方式建议】{_strip_page_markers(parsed['lifestyle'])[:300]}")

    return "\n".join(lines)
