# -*- coding: utf-8 -*-
"""Ollama 调用封装：连接本地 Ollama 做大模型问答（流式 + 非流式）。

增强点：
1. 启动时自动探测 Ollama 已拉取的模型，若 config 指定的模型名不存在，
   自动回退到最接近的可用模型（优先 qwen3 系列），并打印清晰提示。
2. health() 返回真实模型名 + 详细状态，方便前端和排错定位。
"""
import json
import requests


class OllamaClient:
    def __init__(self, base_url="http://localhost:11434", model="qwen3:8b",
                 temperature=0.7, num_ctx=4096):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.requested_model = model  # 配置里原本写的模型名
        self.temperature = temperature
        self.num_ctx = num_ctx
        self._last_error = ""
        # 启动时自动探测并校准模型名
        self._autodetect_model()

    # ---------- 模型探测 ----------
    def _list_models(self):
        """获取 Ollama 已拉取的模型名列表。失败返回 []。"""
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=3)
            if r.status_code == 200:
                return [m.get("name", "") for m in r.json().get("models", [])]
        except Exception as e:
            self._last_error = str(e)
        return []

    def _autodetect_model(self):
        """若配置的模型不存在，自动回退到最接近的可用模型。"""
        models = self._list_models()
        if not models:
            # Ollama 没连上或没模型，保持配置值，等 health() 报告
            return

        # 配置名精确匹配 → 直接用
        if self.model in models:
            return

        # 配置名带 ":latest" 或大小写差异 → 尝试规范化匹配
        norm_requested = self.model.split(":")[0].lower()
        for m in models:
            if m.split(":")[0].lower() == norm_requested:
                self.model = m
                print(f"[Ollama] 模型名规范化：{self.requested_model} → {m}")
                return

        # 精确匹配和前缀匹配都失败 → 按优先级回退
        # 优先级：qwen3 系列 > qwen 系列 > 任意模型
        def rank(name):
            n = name.lower()
            if n.startswith("qwen3"):
                return 0
            if n.startswith("qwen"):
                return 1
            return 2

        models_sorted = sorted(models, key=rank)
        fallback = models_sorted[0]
        print(f"[Ollama] ⚠️ 配置模型 {self.requested_model} 不存在，已自动回退到 {fallback}")
        print(f"[Ollama] 可用模型：{', '.join(models)}")
        self.model = fallback

    # ---------- 健康检查 ----------
    def health(self):
        """检查 Ollama 是否可用。返回 (ok, message)。"""
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=3)
            if r.status_code == 200:
                models = [m.get("name") for m in r.json().get("models", [])]
                if not models:
                    return False, "Ollama 在线，但还没有任何模型（请 ollama pull qwen3:8b）"
                # 判断当前用的模型是否真实存在
                if self.model in models:
                    return True, f"Ollama 在线 · 模型 {self.model} 已就绪"
                else:
                    # 触发一次自动回退
                    self._autodetect_model()
                    if self.model in models:
                        return True, f"Ollama 在线 · 模型已自动切换到 {self.model}"
                    return False, f"模型 {self.model} 不存在，可用：{', '.join(models)}"
            return False, f"Ollama 返回 {r.status_code}"
        except Exception as e:
            return False, f"无法连接 Ollama（{self.base_url}）：{e}"

    def list_models(self):
        """返回当前 Ollama 的模型列表（供 /api/health 透出）。"""
        return self._list_models()

    # ---------- 对话 ----------
    def chat(self, messages, system=None, stream=False):
        """非流式对话。messages: [{'role':'user','content':'...'}, ...]"""
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_ctx": self.num_ctx,
            },
        }
        if system:
            payload["system"] = system
        r = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=300)
        r.raise_for_status()
        data = r.json()
        return data.get("message", {}).get("content", "")

    def chat_stream(self, messages, system=None):
        """流式对话，逐段 yield 文本（边生成边返回，改善等待体验）。"""
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": self.temperature,
                "num_ctx": self.num_ctx,
            },
        }
        if system:
            payload["system"] = system
        with requests.post(f"{self.base_url}/api/chat", json=payload, stream=True, timeout=600) as r:
            r.raise_for_status()
            for raw in r.iter_lines(decode_unicode=True):
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                piece = obj.get("message", {}).get("content", "")
                if piece:
                    yield piece
                if obj.get("done"):
                    break
