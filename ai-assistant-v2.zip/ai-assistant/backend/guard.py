# -*- coding: utf-8 -*-
"""回答边界守卫（v2.0）：提问侧分类 + 回答侧校验 + 剂量拦截。

职责：
1. 提问进入模型前，判断属于哪一类 → 决定「直接回话术」还是「交给模型」；
2. 模型产出后，做合规兜底与剂量外泄拦截。

⚠️ 所有「哪些词触发、触发后说什么话」都配置在 **guard_rules.json**；
   「哪些成分名要放行」配置在 **ingredients.json**。
   改配置即可，不用改代码，重启后端生效。

【四类出口（v2.0 重构）】
  identity  身份/能力询问 → 自我介绍 + 能给什么，不再拼「这是无关问题」
  chat      无关闲聊（天气/吃什么/算术/翻译）→ 礼貌驳回，不承诺开会
  redline   孕产/用药/疾病/过敏/危险期 → 转营养师，标记优先
  promise   疗效承诺/诊断请求 → 合规改写
  gap       业务范围内但知识库没收录 → 升级人工答疑

【成分白名单放行（v1.3 起，v2.0 增强）】
提问中命中 136 种成分名/别名 → 视为业务问题放行：
  - 闲聊、危险期 → 仍然拦截
  - 其余（诊断/承诺/用药/过敏/孕产/疾病）→ 放行，但注入「成分口径约束」
放行 ≠ 放开：只讲机制不下结论、剂量标示例值、不生成配方、标来源。
"""
import json
import re
from pathlib import Path

_DIR = Path(__file__).resolve().parent
_RULES_PATH = _DIR / "guard_rules.json"
_INGREDIENTS_PATH = _DIR / "ingredients.json"


def _load_rules():
    with open(_RULES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_ingredients():
    try:
        with open(_INGREDIENTS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"成分白名单": [], "泛称": {"词": []}}


def _split_words(s):
    """把逗号分隔的字符串拆成词列表（去空、去空格）。"""
    if not s:
        return []
    return [w.strip() for w in s.split(",") if w.strip()]


def _hit_any(text, words):
    return any(w in text for w in words)


def _has_any(text, words):
    return any(w and w in text for w in words)


def _hit_category(text, redline_map):
    """在红线类里找出命中的第一个子类别名（如「用药」），未命中返回 None。"""
    for cat, words_str in redline_map.items():
        words = _split_words(words_str)
        if any(w in text for w in words):
            return cat
    return None


# ===================== 成分白名单 =====================

def _alias_hit(q_lower, alias):
    """判断别名是否命中，规避短英文别名的误伤。

    规则：
    - 中文别名：直接子串匹配（中文无词边界，安全）。
    - 纯英文/数字别名：
        * 长度 >= 5 → 子串匹配（如 "Thiamine"、"Silymarin"）；
        * 长度 2-4 → 要求两侧不是英文字母，
          避免 "VA" 命中 "value"、"NR" 命中 "energy"、"Iron" 命中 "environment"。
    """
    a = (alias or "").strip()
    if not a:
        return False
    al = a.lower()
    if not al:
        return False
    if not al.isascii():
        # 中文：先原样匹配，再尝试去掉问句里的空格（"鱼 油" → "鱼油"）
        if al in q_lower:
            return True
        import re as _re
        return al in _re.sub(r"\s+", "", q_lower)
    if len(al) >= 5:
        return al in q_lower
    m = re.search(r"(?<![a-z])" + re.escape(al) + r"(?![a-z])", q_lower)
    return bool(m)


def find_ingredients(question):
    """在提问中查找命中的成分（含别名）。

    返回 [(标准名, 命中的原文词), ...]，按命中的原文词长度降序（长词优先）。
    同一成分只记一次，记最长命中词。
    """
    data = _load_ingredients()
    q = question or ""
    ql = q.lower()
    found = []
    for item in data.get("成分白名单", []):
        std = item.get("标准名", "")
        en = item.get("英文名", "")
        candidates = [std] + ([en] if en else []) + list(item.get("别名", []))
        best = None
        for alias in candidates:
            if _alias_hit(ql, alias):
                if best is None or len(alias) > len(best):
                    best = alias
        if best:
            found.append((std, best))
    found.sort(key=lambda x: -len(x[1]))
    return found


def find_generic_terms(question):
    """查找命中的泛称（成分/营养素/剂量等）。泛称只用于提示词，不用于放行。"""
    data = _load_ingredients()
    q = (question or "").lower()
    return [w for w in data.get("泛称", {}).get("词", []) if w and w.lower() in q]


def ingredient_names(question):
    """返回命中的中文标准名列表（供外部展示「你问的是 XX」）。"""
    return [std for std, _ in find_ingredients(question)]


def _ingredient_alias_hits(question):
    """返回命中成分的全部检索词（中文名+英文名+别名），用于打分时匹配英文标题。"""
    data = _load_ingredients()
    q = (question or "").lower()
    names = set()
    hit_stds = {std for std, _ in find_ingredients(question)}
    if not hit_stds:
        return []
    for item in data.get("成分白名单", []):
        if item.get("标准名") in hit_stds:
            names.add(item.get("标准名", ""))
            names.add(item.get("英文名", ""))
            for a in item.get("别名", []):
                names.add(a)
    return [(n, n) for n in names if n]


# ===================== 四类问句识别 =====================

# 多轮追问的短路词：出现即说明是承接上文，不该判成闲聊/无关
FOLLOWUP_PATTERNS = re.compile(
    r"^(再|那|还有|另外|继续|接着|然后|所以|就是说|换句话说)"
    r"|(详细|具体|展开|补充|多说|举个例子)"
    r"|(第一|第二|第三|第四|上面|刚才|前面|后面|这部分|那段|这个|那个|它|他)"
)

# 身份类问句（含正则，覆盖「你是谁」「你是什么」「你能干什么」各种写法）
IDENTITY_PATTERNS = re.compile(
    r"(你|您)(到底)?(是|叫)(谁|什么|啥|哪个)"
    r"|你是(个)?(什么|啥)(AI|助手|机器人|东西)"
    r"|你(能|会|可以)(做|干|帮)(什么|啥|哪些)"
    r"|你(有|具备)(什么|哪些)(功能|能力|用)"
    r"|介绍一下你自己|你的(功能|能力|用途|定位)"
    r"|(怎么|如何)(用|使用)(你|这个助手)"
)


def is_followup(question, history):
    """判断是否是多轮追问。

    只认「明确承接上文」的信号：
      - 以「再/那/还有/继续…」开头；
      - 含「详细/具体/展开/补充…」这类要求展开的词；
      - 带指代（第一/第二/上面/刚才/这个/它…）。
    注意：不能按长度判断——「今天天气怎么样」也很短，但它不是追问。
    """
    if not history:
        return False
    q = (question or "").strip()
    if not q:
        return False
    return bool(FOLLOWUP_PATTERNS.search(q))


def classify(question, history=None):
    """问句分类（不含成分放行判断）。

    返回 dict: {
      "kind": identity|chat|redline|promise|diagnosis|plain,
      "sub":  红线子类别（如「用药」），无则空,
      "followup": bool
    }
    """
    rules = _load_rules()
    cats = rules["categories"]
    q = question or ""
    history = history or []

    # 0. 身份类最优先（避免被 chat 的「你是谁」抢走）
    ident_words = _split_words(cats.get("identity", {}).get("触发词", ""))
    if IDENTITY_PATTERNS.search(q) or _has_any(q, ident_words):
        return {"kind": "identity", "sub": "", "followup": False}

    # 1. 红线（危险期优先，安全底线）——多轮也不能豁免
    redline_map = cats["redline"]["触发词"]
    danger_words = _split_words(redline_map.get("危险期", ""))
    if _has_any(q, danger_words):
        return {"kind": "redline", "sub": "危险期", "followup": False}
    cat = _hit_category(q, redline_map)
    if cat:
        return {"kind": "redline", "sub": cat, "followup": False}

    # 2. 诊断 / 疗效承诺——多轮也不能豁免
    diag_regex = cats["diagnosis"].get("正则", "")
    if _has_any(q, _split_words(cats["diagnosis"]["触发词"])) or (
        diag_regex and re.search(diag_regex, q)
    ):
        return {"kind": "diagnosis", "sub": "", "followup": False}
    if _has_any(q, _split_words(cats["promise"]["触发词"])):
        return {"kind": "promise", "sub": "", "followup": False}

    # 3. 闲聊（多轮里说天气也照样拦，不按长度豁免）
    chat_words = _split_words(cats["chat"]["触发词"])
    chat_regex = cats["chat"].get("正则", "")
    if _has_any(q, chat_words) or (chat_regex and re.search(chat_regex, q)):
        return {"kind": "chat", "sub": "", "followup": False}

    followup = is_followup(q, history)
    return {"kind": "plain", "sub": "", "followup": followup}


def check_question(question, history=None):
    """提问侧拦截。

    返回 (blocked, reply, category)
    - blocked=True：直接返回话术，不走模型
    - category ∈ identity/chat/redline/diagnosis/promise/None
    """
    cls = classify(question, history)
    kind = cls["kind"]
    templates = _load_rules()["templates"]
    q = question or ""

    # 身份类：始终由固定话术回答（不消耗模型，也避免自相矛盾）
    if kind == "identity":
        return True, templates.get("identity", ""), "identity"

    # 成分白名单：命中具体成分则按业务问题放行
    ingredient_hits = find_ingredients(q)
    if ingredient_hits:
        # 危险期永远拦（安全底线）
        if kind == "redline" and cls["sub"] == "危险期":
            return True, templates["redline"].format(category="危险期"), "redline"
        # 闲聊永远拦
        if kind == "chat":
            return True, templates["chat"], "chat"
        # 其余放行（诊断/承诺/用药/过敏/孕产/疾病）
        return False, "", None

    # 未命中成分：按其类别走对应话术
    if kind == "redline":
        return True, templates["redline"].format(category=cls["sub"]), "redline"
    if kind == "diagnosis":
        return True, templates["diagnosis"], "diagnosis"
    if kind == "promise":
        return True, templates["promise"], "promise"
    if kind == "chat":
        return True, templates["chat"], "chat"

    return False, "", None


def ingredient_context_note(question):
    """若提问涉及成分，返回一段追加到提示词的「成分问题作答约束」；否则返回空串。"""
    hits = find_ingredients(question)
    if not hits:
        if find_generic_terms(question):
            return (
                "\n\n【本次提问涉及营养素成分的口径要求】\n"
                "1. 只依据知识库（尤其 C-27 成分速查总表、C-26 成分与药物相互作用说明）作答，标注来源；\n"
                "2. 剂量一律说明是「本配方示例值」，实际由算法按个人风险输出、因人而异；\n"
                "3. 库中没有的成分、剂量、研究数据，一律回复「该问题已记录，4P 健康研究院将统一安排线上视频会议答疑」，禁止推测；\n"
                "4. 不提供「该不该加/减某个成分」的建议（属配方生成，不在助手职责内）。"
            )
        return ""

    names = "、".join(sorted({std for std, _ in hits}))
    return (
        f"\n\n【本次提问涉及成分：{names}】\n"
        "回答必须遵守以下成分口径：\n"
        "1. 【只讲机制、不下结论】若问题涉及药物相互作用（他汀、抗凝药、降糖药等）、过敏或孕产，"
        "只陈述知识库（C-27 / C-26）里写明的机制与风险提示原文，"
        "明确说明「配方已由算法按个人风险做过安全校验」，但不得声称「安全/可以吃/没冲突」，"
        "也不得声称「不安全/不能吃」——一律引导「请遵医嘱，以医生判断为准」。\n"
        "2. 【剂量口径】剂量一律说明是「本配方示例值」，实际由算法按个人风险输出、因人而异；"
        "不给具体安全上限数值。\n"
        "3. 【不生成配方】只解释报告里为什么有这个成分，不回答「该不该加/减」。\n"
        "4. 【不做诊断、不做疗效承诺】只描述营养支持层面的机制，不说「能治好/能治疗」。\n"
        "5. 【来源标注】每个成分说明后标注知识库来源标题。"
        f"\n6. 【当前问的是：{names}】不要顺带讲用户没问的成分。"
    )


# ===================== 回答侧校验 =====================

# 剂量片段：数字 + 可选范围 + 单位
_DOSE_UNIT = r"(?:mg|毫克|mcg|ug|μg|微克|IU|iu|国际单位|ml|毫升|g|克)"
_DOSE_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(?:[-–~至]\s*(\d+(?:\.\d+)?))?\s*" + _DOSE_UNIT,
    re.IGNORECASE,
)


def find_doses(text):
    """提取文本里的剂量片段（用于剂量外泄拦截）。返回命中的原文列表。"""
    out = []
    for m in _DOSE_RE.finditer(text or ""):
        s = m.group(0).strip()
        # 过滤明显不是剂量的（如 "5 年" 已被单位限制，不会命中；"1 g" 会命中）
        if s and s not in out:
            out.append(s)
    return out


CLIENT_SCRIPT_HEAD = re.compile(r"(可发给客户的话术|发给客户的话术|客户话术|给客户的话术|微信话术)")
CLIENT_SCRIPT_HEAD_LOOSE = re.compile(r"(可发给客户|发给客户|客户版话术)")

# 绝对化用语里「最/第一」误伤严重（最容易 / 第一周 / 第一次复查），需按上下文排除
_ABS_SOFT = ("最", "第一")
# 逐个安全搭配剔除（含「最」字的正常词），剔除后仍残留「最」才算违规
_ABS_SAFE_PATTERNS = [
    re.compile(p) for p in (
        r"最(近|初|后|先|终|新|末|基本|主要)",
        r"最好(?!的)(?=不|别|能|可以|是|在|先|还|也|按|选|用|吃|放|晚|早|问|让|去|把|每|一天|每天|一段时间|先)",
        r"最(容易|好多|好些|大多|常见|典型|重要|关键|大|小|高|低|多|少|快|慢)",
        r"最.{0,3}的是",
        r"第(一|1)(周|次|步|阶段|天|个月|年|步做|次复查|条)",
    )
]

# 真正违规的「最」搭配（广告法绝对化）
_ABS_STRICT_RE = re.compile(
    r"最(有效|好(?!不|别|能|可以|是|在|先|还|也|按|选|用|吃|放|晚|早|问|让|去|把|每|一天|每天|一段时间)"
    r"|佳|优|强|安全|健康|专业|先进|领先|权威|科学|顶尖|理想|完美|划算|超值|低价)"
)


def _hit_absolute(text, words):
    """绝对化用语判定：
    - 「最」：先看是否命中广告法绝对化搭配（最有效/最好/最安全…）→ 违规；
            否则剔除正常搭配（最近/最容易/最重要的是），残留才算违规。
    - 「第一」：剔除「第一周/第一次/第一步」等序数用法后，残留才算违规。
    - 其余词（唯一/顶级/保证见效…）直接命中即违规。
    """
    for w in words:
        if w in _ABS_SOFT:
            continue
        if w and w in text:
            return True
    if "最" in words and "最" in text:
        if _ABS_STRICT_RE.search(text):
            return True
        rest = text
        for pat in _ABS_SAFE_PATTERNS:
            rest = pat.sub("", rest)
        if "最" in rest:
            return True
    if "第一" in words and "第一" in text:
        rest = text
        for pat in _ABS_SAFE_PATTERNS:
            rest = pat.sub("", rest)
        if "第一" in rest:
            return True
    return False


def sanitize_client_script(answer):
    """输出侧拦截：第 3 段「可发给客户的话术」里若出现具体剂量，整句改写为报告指引。

    返回 (answer, touched)
    """
    text = answer or ""
    if not text:
        return text, False

    # 找到「客户话术」段落起点
    m = CLIENT_SCRIPT_HEAD.search(text) or CLIENT_SCRIPT_HEAD_LOOSE.search(text)
    if not m:
        return text, False

    head_end = m.end()
    # 段落终点：下一个 4) / 免责声明 / 结尾
    rest = text[head_end:]
    tail_m = re.search(r"(\n\s*4[\)）\.]|免责声明|以上解读仅供)", rest)
    seg_end = head_end + (tail_m.start() if tail_m else len(rest))
    seg = text[head_end:seg_end]

    doses = find_doses(seg)
    if not doses:
        return text, False

    # 把段落里带剂量的句子替换为统一口径
    new_lines = []
    touched = False
    for line in seg.split("\n"):
        if find_doses(line):
            stripped = line.strip().lstrip("·-•* ").strip()
            if stripped:
                new_lines.append("· 具体剂量请以你手上这份《精准营养干预方案》报告为准，"
                                 "每个人的剂量都是按检测结果单独算的，不适合通用数字。")
                touched = True
            # 空的带剂量行直接丢弃
            continue
        new_lines.append(line)

    if not touched:
        return text, False

    new_seg = "\n".join(new_lines)
    return text[:head_end] + new_seg + text[seg_end:], True


def sanitize_answer(answer):
    """回答侧后置校验：检查模型产出里是否漏出禁用词/诊断表述。
    返回 (answer, flagged)。命中则追加一段合规兜底说明（不删除原文，避免截断语义）。
    """
    rules = _load_rules()
    check_words = rules["回答侧校验词"]
    check_replies = rules["回答侧校验话术"]

    flagged = False
    a = answer or ""

    # 先做剂量拦截（客户话术段落）
    a, dose_touched = sanitize_client_script(a)
    flagged = flagged or dose_touched

    # 再按配置顺序：诊断类表述 → 医疗承诺词 → 绝对化用语
    for key, reply in check_replies.items():
        words = _split_words(check_words.get(key, ""))
        hit = False
        if words:
            if key == "绝对化用语":
                hit = _hit_absolute(a, words)
            else:
                hit = _hit_any(a, words)
        if hit:
            if reply not in a:   # 避免重复追加
                a += reply
                flagged = True

    return a, flagged


# ===================== 知识命中判定 =====================

def knowledge_gap_reply():
    return _load_rules()["templates"].get("knowledge_gap", "")


def strict_kb_enabled():
    """是否开启「严格只答知识库内容」开关。"""
    return bool(_load_rules().get("严格只答知识库", {}).get("开启", False))


# 英文专论标题特征：只有英文名 + 连字符，说明是「成分专著」而非「业务文档」
_EN_TITLE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-\s\(\),\.]*$")

# 业务问句里常见的维度词（命中文档正文即加分）
_BIZ_ANCHORS = [
    "靶点", "风险等级", "配方", "剂量", "服法", "怎么吃", "历史数据", "对比",
    "干预路径", "生活方式", "常见问题", "报告", "指标", "效果", "多久", "周期",
    "复查", "评估", "算法", "原料库", "成分表", "解读", "维度", "问卷",
]


# 常见虚词/疑问词，不参与词面匹配
_STOP_TERMS = set("""怎么 怎样 如何 什么 为什么 哪些 哪个 这个 那个 这些 那些 我的 你的
可以 能否 是不是 有没有 一下 一些 相关 情况 问题 请问 帮我 告诉 知道 意思 具体 详细
的呢 了吗 的话 时候 应该 需要 要不要 好不好 行不行""".split())


def _split_terms(text):
    """粗粒度切词：按标点/空格切开，再去掉虚词与单字，保留 2 字以上片段。"""
    import re as _re
    parts = _re.split(r"[\s,，。、；;：:？?！!（）()\[\]【】\"'\u3000·\-—]+", text or "")
    out = []
    for p in parts:
        p = p.strip()
        if len(p) < 2:
            continue
        if p in _STOP_TERMS:
            continue
        out.append(p)
    return out


def score_hits(question, hits):
    """给检索结果打「能不能回答这个问题」的分，而不是只看相似度。

    评分构成（0~1）：
      - 标题实体命中（问句里的成分名 / 维度词出现在标题）→ +0.45
      - 正文实体命中（成分名出现在正文）→ +0.25
      - 维度锚点命中（正文含"靶点/配方/服法"等业务词）→ +0.15
      - 标题是英文专论但问句没点成分 → 扣分（业务问题不该被专论抢走）
      - 正文有效长度 → +0.15

    返回 [(hit, score), ...]，按分数降序。
    """
    q = question or ""
    ql = q.lower()
    ing_names = ingredient_names(q)
    has_ingredient = bool(ing_names)
    biz_hit = any(a in q for a in _BIZ_ANCHORS)

    out = []
    for h in (hits or []):
        title = (h.get("title") or "").strip()
        content = (h.get("content") or "").strip()
        score = 0.0

        # 1. 实体命中：中文标准名、英文名、命中的原文别名，任一出现即算
        title_l = title.lower()
        content_l = content.lower()
        if has_ingredient:
            alias_hits = [a.lower() for _, a in _ingredient_alias_hits(q)]
            name_hits = [n.lower() for n in ing_names] + alias_hits
            # 英文标题里的 "Vitamin-D" 与问句 "维生素 D" 属于同一成分：
            # 标题能匹配英文名/别名 也算命中（原来只比中文名，导致 Vitamin-D 只拿 0.15）
            title_match = any(n and (n in title_l or n.replace(" ", "-") in title_l) for n in name_hits)
            body_match = any(n and n in content_l for n in name_hits)
            if title_match:
                score += 0.45
            elif body_match:
                score += 0.25
        # 维度词命中标题
        if any(a in title for a in _BIZ_ANCHORS):
            score += 0.20

        # 2. 业务锚点命中：必须「问题里的词真的出现在正文/标题里」才算，不能只看有没有维度词
        #    （原来只要正文含任何一个维度词就 +0.15，导致《风险等级怎么看》成了万能文档）
        q_terms = [t for t in _split_terms(q) if len(t) >= 2]
        lexical = sum(1 for t in q_terms if t in title or t in content)
        if q_terms and lexical:
            score += min(0.30, 0.12 * lexical)

        # 3. 英文专论惩罚：问的是业务问题（没点成分），却返回英文标题专论
        is_en_title = bool(_EN_TITLE_RE.match(title)) and not re.search(r"[\u4e00-\u9fff]", title)
        if is_en_title and not has_ingredient and biz_hit:
            score -= 0.30

        # 4. 正文体量
        if len(content) >= 300:
            score += 0.15
        elif len(content) >= 60:
            score += 0.08

        out.append((h, round(max(score, 0.0), 3)))

    out.sort(key=lambda x: -x[1])
    return out


def check_knowledge_hit(hits, question=None):
    """知识库检索后判断：是否命中「能回答这个问题」的内容。

    返回 (ok, reply, scored)
    - ok=True：检索到可用内容，可交给模型
    - ok=False：判为知识缺口 → 返回升级话术，不调模型

    判定规则（严格模式）：
      1. 至少一条 hit 有实质正文（正文 >= 10 字或标题 >= 4 字）；
      2. 若传了 question，则最高分需达到阈值（默认 0.25）；
         纯英文专论命中、业务问句无实体命中时，分数会低于阈值 → 判缺口。
    """
    valid = []
    for h in (hits or []):
        content = (h.get("content") or "").strip()
        title = (h.get("title") or "").strip()
        if len(content) >= 10 or len(title) >= 4:
            valid.append(h)

    if not valid:
        return (False, knowledge_gap_reply(), []) if strict_kb_enabled() else (True, "", [])

    scored = score_hits(question, valid) if question else [(h, 1.0) for h in valid]
    best = scored[0][1] if scored else 0.0

    threshold = 0.25
    try:
        threshold = float(_load_rules().get("检索命中阈值", threshold))
    except Exception:
        pass

    if best >= threshold:
        return True, "", scored

    if strict_kb_enabled():
        return False, knowledge_gap_reply(), scored
    return True, "", scored
