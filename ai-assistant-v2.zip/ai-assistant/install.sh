#!/bin/bash
# ============================================================
#  精准营养 AI 助手 · 一键部署（傻瓜版）
#  用法（在服务器上执行，一行即可）：
#     curl -fsSL <部署包地址>/install.sh | bash
#  或先下载解压后：
#     bash install.sh
# ============================================================

set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok(){ echo -e "${GREEN}✅ $1${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $1${NC}"; }
err(){ echo -e "${RED}❌ $1${NC}"; }

APP_NAME="precision-nutrition-assistant"
PORT="${PORT:-8000}"
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=================================================="
echo "  4P 精准营养方案解读 AI 助手 · 一键部署"
echo "  目录: $BASE_DIR   端口: $PORT"
echo "=================================================="

# ---------- 1. 系统依赖 ----------
echo ""
echo "[1/5] 检查并安装系统依赖..."
if command -v apt-get >/dev/null 2>&1; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq 2>/dev/null || true
  apt-get install -y -qq python3 python3-pip curl >/dev/null 2>&1 || true
elif command -v yum >/dev/null 2>&1; then
  yum install -y python3 python3-pip curl >/dev/null 2>&1 || true
fi
command -v python3 >/dev/null 2>&1 || { err "python3 安装失败，请手动安装后重试"; exit 1; }
ok "python3 就绪：$(python3 --version 2>&1)"

# ---------- 2. Python 依赖 ----------
echo ""
echo "[2/5] 安装 Python 依赖（fastapi/uvicorn/requests/pypdf）..."
python3 -m pip install --upgrade pip -q 2>/dev/null || true
python3 -m pip install -q -r "$BASE_DIR/requirements.txt" 2>&1 | tail -3
ok "Python 依赖安装完成"

# ---------- 3. 配置混元 API Key ----------
echo ""
echo "[3/5] 配置云端大模型（腾讯混元）..."
CFG="$BASE_DIR/config.json"
CUR_KEY=$(python3 -c "import json;print(json.load(open('$CFG'))['llm'].get('api_key',''))" 2>/dev/null || echo "")

if [ -n "$KEY" ]; then
  # 支持环境变量传入：KEY=sk-xxx bash install.sh
  python3 - "$CFG" "$KEY" <<'PY'
import json,sys
p,k=sys.argv[1],sys.argv[2]
c=json.load(open(p))
c['llm']['api_key']=k
c['llm']['enabled']=True
c['llm']['provider']='hunyuan'
c['llm']['model']='hunyuan-turbos-latest'
json.dump(c,open(p,'w'),ensure_ascii=False,indent=2)
print('已写入 API Key')
PY
  ok "混元 API Key 已配置"
elif [ -n "$CUR_KEY" ] && [ "$CUR_KEY" != "YOUR_API_KEY_HERE" ] && [ "$CUR_KEY" != "在此填写你的APIKey" ]; then
  ok "检测到已有 API Key，跳过"
else
  warn "未配置混元 API Key（服务仍可启动，将回退到知识库原文模式）"
  echo "    稍后可编辑：$CFG  里的 llm.api_key"
fi

# ---------- 4. 注册 systemd 服务 ----------
echo ""
echo "[4/5] 注册常驻服务..."
SERVICE_FILE="/etc/systemd/system/${APP_NAME}.service"
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=4P Precision Nutrition AI Assistant
After=network.target

[Service]
Type=simple
WorkingDirectory=${BASE_DIR}/backend
ExecStart=$(command -v python3) -m uvicorn app:app --host 0.0.0.0 --port ${PORT}
Restart=always
RestartSec=3
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable "$APP_NAME" >/dev/null 2>&1 || true
systemctl restart "$APP_NAME"
ok "systemd 服务已注册并启动"

# ---------- 5. 自检 ----------
echo ""
echo "[5/5] 自检服务状态..."
sleep 4
if curl -s -m 5 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
  HEALTH=$(curl -s -m 5 "http://127.0.0.1:${PORT}/api/health")
  ok "服务健康检查通过"
  echo ""
  echo "=================================================="
  echo -e "${GREEN}  🎉 部署成功！${NC}"
  echo "=================================================="
  echo "  本机访问:  http://127.0.0.1:${PORT}"
  echo "  外网访问:  http://<你的公网IP>:${PORT}"
  echo "  规则管理:  http://<你的公网IP>:${PORT}/guard"
  echo ""
  echo "  健康详情: $HEALTH"
  echo ""
  echo "  常用命令："
  echo "    查看状态: systemctl status ${APP_NAME}"
  echo "    查看日志: journalctl -u ${APP_NAME} -f"
  echo "    重启服务: systemctl restart ${APP_NAME}"
  echo ""
  warn "记得在【腾讯云控制台 → 防火墙】放行 ${PORT} 端口，否则外网打不开！"
else
  err "服务未正常启动，最近日志："
  journalctl -u "$APP_NAME" -n 30 --no-pager
  exit 1
fi
