# ceshi.54hrm.com 部署说明（保留 iframe 壳 · 汇总到服务器后端）

## 一、这次改了什么（对照你的现状）

现状问题：
- `ceshi.54hrm.com` 所有路径 → 返回 iframe 壳 → 套 `plan-explainer.app.workbuddy.host`
- 那个托管版界面会调 **`/api/kb`** 检索知识库，但你的后端**没有这个接口** → 检索失效
- 你的后端 `/api/chat` 因模型不通 → 500

本次改造（已在本地实测通过）：

| 项目 | 改动 |
|------|------|
| **新增 `/api/kb`** | 补齐托管版前端要的检索接口，返回 `{hits:[{title,content,url}]}` |
| **新增 `/api/ask` 与 `/api/ask/stream`** | 统一问答入口，硬拦截 + 严格只答知识库 |
| **强化 `/api/chat`** | 未命中知识库 → 固定话术，不调模型 |
| **强化硬拦截** | 闲聊/红线/诊断/疗效承诺 四类，命中即固定话术 |
| **强化严格模式** | `check_knowledge_hit` 收紧：命中但正文为空也视为未命中 |
| **补齐混元接入** | `cloud_llm.py`，填 Key 即用 |

## 二、接口清单（部署后可用）

```
GET  /api/health              健康检查（含 cloud_ok / kb_mode）
GET  /api/customers           示例客户
GET  /api/kb?q=&top_k=3       ★ 知识库检索（托管版前端要调这个）
POST /api/chat                问答（硬拦截 + 严格只答知识库）
POST /api/ask                 ★ 统一问答（同 /api/chat，带客户）
POST /api/ask/stream          ★ 流式问答
POST /api/analyze             客户方案分析
POST /api/analyze/stream      客户方案分析（流式）
POST /api/upload-report       上传报告 PDF
POST /api/report/analyze/stream  报告四维度解读（流式）
GET/POST /api/guard-rules     拦截规则读写
GET  /guard                   拦截规则可视化管理页
GET  /                        嵌入版前端
```

## 三、部署步骤（在服务器上执行）

### 3.1 上传（两种方式，选一个）

**方式 A：网页终端上传（推荐，不用装工具）**
1. 从 WorkBuddy 工作区下载 `ai-assistant.zip`
2. 登录腾讯云控制台 → 轻量应用服务器 → 登录（网页终端）
3. 点终端窗口右上角的「上传文件」，选本地 `ai-assistant.zip`，传到 `/root/`
4. 终端里确认：`ls -lh /root/ai-assistant.zip`

**方式 B：本机命令行上传**
```bash
scp ai-assistant.zip root@101.42.26.85:/root/
```

### 3.2 解压 + 原地升级（一条命令）
```bash
cd /root && unzip -oq ai-assistant.zip -d /root/pkg && cd /root/pkg/ai-assistant && bash upgrade.sh
```

`upgrade.sh` v2 会自动做完这些事：

| 步骤 | 做什么 |
|:--:|---|
| 1 | 自动定位现有应用目录（从运行进程 / 常见路径） |
| 2 | 自动探测后端端口（进程参数 → Nginx 反代 → 常见端口探活） |
| 3 | 整目录备份为 `原目录.bak.时间戳`，失败即中止不修改 |
| 4 | 替换 backend / frontend / data / 话术库，清掉 `__pycache__` |
| 5 | 保留你原来的混元 `api_key`，装依赖 |
| 6 | 重启（优先 systemd，找不到就按裸进程 setsid 拉起） |
| 7 | 自检 + 4 条拦截回归（闲聊/红线/身份/算术） |

**如果自动定位错目录**，手动指定重跑：
```bash
APP_DIR=/你的旧应用目录 PORT=8000 bash upgrade.sh
```

### 3.3 验证（脚本末尾已自动跑，也可手动复查）
```bash
curl http://127.0.0.1:8000/api/health
# 新版只返 {ok, kb, msg}；要看详情加 ?detail=1

curl "http://127.0.0.1:8000/api/kb?q=%E7%BB%B4%E7%94%9F%E7%B4%A0D"
# 应返回 hits + relevance + gate_ok

curl -X POST http://127.0.0.1:8000/api/ask -H "Content-Type: application/json" -d '{"question":"今天天气怎么样"}'
# 应返回 "blocked":true, "block_category":"chat"

curl -X POST http://127.0.0.1:8000/api/ask -H "Content-Type: application/json" -d '{"question":"维生素D有什么作用"}'
# 成分白名单内 + 知识库命中 → 应返回正常答案（不 blocked）
```

### 3.4 填混元 Key（有 Key 后）
```bash
# 编辑 config.json，把 llm.api_key 改成你的 Key
nano /你的应用目录/config.json

# 重启
systemctl restart precision-nutrition-assistant
# 或（裸进程方式）
pkill -f "uvicorn app:app"; cd /你的应用目录/backend && nohup python3 -m uvicorn app:app --host 0.0.0.0 --port 8000 &
```

### 3.4 验证
```bash
curl http://127.0.0.1:8000/api/health        # 应看到 cloud_ok
curl "http://127.0.0.1:8000/api/kb?q=%E7%BA%A2%E6%9B%B2%E7%B1%B3"   # 应返回 hits
curl -X POST http://127.0.0.1:8000/api/chat -H "Content-Type: application/json" -d '{"question":"今天天气怎么样？"}'
# 应返回 blocked:true, block_category:chat
```

### 3.5 Nginx 保持现状
**不用改 Nginx**。你现在的 iframe 壳保持不变，托管版界面会继续调
`https://ceshi.54hrm.com/api/kb`，这次后端**补上了这个接口**，检索链路就通了。

> 注意：确认 Nginx 的 `/api/` 位置没有被子路径规则吃掉。检查：
> ```bash
> grep -rn "location" /etc/nginx/sites-enabled/ /etc/nginx/conf.d/ 2>/dev/null
> ```
> 需要保证 `/api/` 能转发到后端端口（8000）。

## 四、硬拦截话术（四类 + 未命中）

| 类别 | 触发示例 | 返回 |
|------|---------|------|
| 闲聊 | 今天天气、晚饭吃什么 | 拉回方案解读 + 推荐问题 |
| 红线-用药 | 我在吃他汀、二甲双胍 | 须营养师判断 + 记录 + 优先答疑 |
| 红线-孕产 | 怀孕能吃吗 | 同上 |
| 红线-疾病 | 能治脂肪肝吗、确诊 | 同上 |
| 红线-过敏 | 过敏能吃吗 | 同上 |
| 诊断 | 帮我确诊、是不是癌 | 不做诊断，引导就医 |
| 疗效承诺 | 能根治吗、保证见效 | 营养支持口径，不做承诺 |
| 知识缺口 | 库外问题 | 未收录 + 已记录 + 视频答疑 |

**这些词和话术都在 `backend/guard_rules.json` 里，你可以自己改，不用动代码。**
或访问 `/guard` 页面可视化编辑。

## 五、回滚

```bash
rm -rf /你的应用目录 && mv /你的应用目录.bak.日期 /你的应用目录
systemctl restart precision-nutrition-assistant
```
