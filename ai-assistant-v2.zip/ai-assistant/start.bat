@echo off
REM ============================================================
REM  精准营养 AI 助手 · 一键启动脚本（Windows）
REM  双击本文件即可启动
REM ============================================================

cd /d "%~dp0"

echo ==============================================
echo   精准营养 AI 助手 · 一键启动
echo ==============================================

REM 1. 检查 Python
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Python，请先安装 Python 3.9+
    echo        下载地址：https://www.python.org/downloads/
    echo        安装时务必勾选 "Add Python to PATH"
    pause
    exit /b 1
)
echo [OK] Python 已检测到

REM 2. 安装依赖
echo [安装] 正在检查依赖...
python -m pip install -q fastapi uvicorn requests pypdf

REM 3. 检查 Ollama
echo [检查] 本地 Ollama...
curl -s -m 2 http://localhost:11434/api/tags >nul 2>nul
if %errorlevel% equ 0 (
    echo [OK] Ollama 已连接
) else (
    echo [提示] 未检测到 Ollama（降级模式，回答为知识库原文）
    echo        启动 Ollama 后重启本脚本可获得 AI 自然对话
)

REM 4. 打开浏览器
echo [启动] 后端服务（端口 8000）...
start "" http://localhost:8000

REM 5. 启动后端
cd backend
python app.py

pause
