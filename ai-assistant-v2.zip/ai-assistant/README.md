# 精准营养 AI 助手 · 客户方案解读

4P 精准营养实践项目体验服务平台的 AI 助手，基于**云端大模型（腾讯混元/通义等，可切换）+ 乐享知识库**（RAG）+ **代码层硬拦截规则引擎**，实现客户检测报告与营养补剂方案的智能解读。支持以**可拖动浮窗（iframe）**形式嵌入 `4Pwellness.org.cn`，供所有登录机构使用。

## 架构

```
4Pwellness.org.cn（登录后）
   │  嵌入 embed.js → 可拖动浮窗 → iframe 加载 widget.html
   ▼
后端 backend/app.py (FastAPI)
   ├── 把关守卫 guard.py（提问侧拦截 + 回答侧校验，红线/禁用词/未命中→固定话术，不走模型）
   ├── 大模型生成 → 云端 LLM（混元/通义，OpenAI 兼容，优先）→ 本地 Ollama（降级）
   └── 知识检索 → 乐享知识库（AI 语义搜索）
```

## 目录结构

```
ai-assistant/
├── config.json          # 配置（llm云端模型、Ollama、乐享凭证、端口）
├── backend/
│   ├── app.py           # FastAPI 后端主程序
│   ├── cloud_llm.py     # 云端大模型客户端（OpenAI 兼容，混元/通义/DeepSeek）
│   ├── guard.py         # 回答边界守卫（硬拦截规则引擎 + 固定话术）
│   ├── lexiang.py       # 知识库检索（内置 + 乐享API两种模式）
│   ├── ollama_client.py # 本地 Ollama 调用封装（可选降级）
│   └── report_parser.py # 报告 PDF 解析
├── frontend/
│   ├── index.html       # 后台/演示完整页（功能介绍 → 选客户/上传报告 → 四维度分析）
│   ├── widget.html      # 可拖动浮窗（供 4P 站点 iframe 嵌入）
│   └── embed.js         # 4P 前端一行引入的嵌入脚本
└── data/
    ├── customers.json   # 示例客户
    └── knowledge/       # 内置知识库文档（备用）
```

## 快速启动

```bash
# 1. 配置云端模型 Key（config.json 的 llm 块）
#    provider 选 hunyuan(腾讯混元)/qwen(通义千问)/deepseek，api_key 填你的 Key
#    不想用云端、只用本地 Ollama 的话，把 llm.enabled 设为 false 并启动本地 Ollama

# 2. 安装依赖
pip install fastapi uvicorn requests pypdf

# 3. 启动后端
cd backend
python app.py
# 或：uvicorn app:app --host 0.0.0.0 --port 8000

# 4. 打开
#   完整演示页：http://localhost:8000
#   浮窗（iframe 用）：http://localhost:8000/static/widget.html
```

## 云端模型配置（重点）

`config.json` 的 `llm` 块：

```json
"llm": {
  "enabled": true,
  "provider": "hunyuan",              // hunyuan/qwen/deepseek/openai
  "model": "hunyuan-turbos-latest",   // 该厂商的模型名
  "api_key": "YOUR_API_KEY_HERE",     // ← 填你自己的 Key
  "base_url": "",                     // 留空则用厂商默认端点
  "temperature": 0.7,
  "max_tokens": 2048
}
```

- **provider 默认端点**（无需手填 base_url）：腾讯混元 `https://api.hunyuan.cloud.tencent.com/v1`、通义 `https://dashscope.aliyuncs.com/compatible-mode/v1`、DeepSeek `https://api.deepseek.com/v1`。
- **Key 留空/占位**时，后端自动回退到本地 Ollama（若也没启动，则返回知识库检索原文的降级结果）。
- 接口统一走 OpenAI 兼容的 `/chat/completions`，换厂商只改 `provider` 一个字段。

## 回答边界守卫（核心：哪些能答、哪些不能答）

由 `backend/guard.py` 实现**代码层硬拦截**（不经过模型，100% 可控），配合 V3 人设提示词的**软约束**：

| 场景 | 处理 |
|---|---|
| 红线情形（孕产/用药/疾病/过敏/危险期） | 只做一句说明 + 记录标记优先 + "4P 健康研究院统一安排视频答疑"，**不给方案建议** |
| 要求诊断/开处方（"帮我确诊""是不是××病"） | 拒绝，引导就医 |
| 医疗承诺词（治疗/治愈/根治/疗效） | 拦回，替换为"营养支持/有助于改善" |
| 未命中知识库 | 固定兜底话术 + 提示可答相关问题 |
| 回答侧漏出禁用词/绝对化用语 | 后置校验，自动追加合规说明 |

拦截规则集中在 `guard.py` 顶部的词表（`MEDICAL_PROMISE_WORDS` / `ABSOLUTE_WORDS` / `REDLINE_PATTERNS`），营养师改词表即可，无需改代码逻辑。

## 嵌入 4Pwellness.org.cn（可拖动浮窗）

在登录后的页面 `</body>` 前加两行即可：

```html
<div id="p4-ai-widget"></div>
<script src="https://你的部署域名/static/embed.js" data-launch="🌿 营养方案解读助手"></script>
```

- `data-launch`：右下角触发按钮文案（不写则默认"🌿 营养方案解读助手"）。
- `data-auto="true"`：让浮窗页面加载后自动打开。
- 浮窗支持**拖动**（标题栏）、**最小化**、**关闭**（通过 postMessage 通知父页隐藏）。

### 跨域注意事项

iframe 嵌入需满足：
1. 后端已开 CORS（`allow_origins=["*"]`），跨域请求无碍。
2. 若 `4Pwellness.org.cn` 与部署域名不同源，务必让部署服务**不要设置 `X-Frame-Options: DENY/SAMEORIGIN`**，并可在响应头加 `Content-Security-Policy: frame-ancestors 'self' https://4Pwellness.org.cn` 以精确放行。
3. 若 4P 站点自身有 CSP，需在其策略里放行部署域名的 frame-src。

## 功能说明

### 1. 选客户（示例）
选择内置的 3 个示例客户，进入连续聊天，AI 从**靶点分析 / 配方解读 / 方案整合 / 效果评价**四维度解读。

### 2. 上传报告
上传《精准营养干预方案》PDF，后端用 `pypdf` 解析出用户信息、24 维度风险分级、配方成分、干预路径等，再四维度解读。

## 知识库连接说明

`config.json` 中 `lexiang.targets` 控制检索范围（当前指向团队知识库「方案解读助手知识库」）：

```json
"targets": [
  {"type": "space", "id": "67aa2bdb67f14fa3b82ebf59303da552"}
]
```

- `type: "space"` → 检索整个知识库；`type: "kb_entry"` → 只检索某个容器/文件夹。
- 可往 `targets` 数组加多个条目实现多库联合检索。

## 安全底线

- 营养干预不替代药物，AI 回答始终附带安全提醒与免责声明。
- 效果表述用「参考数据 + 个体差异」，不承诺疗效（硬拦截兜底）。
- 红线情形（孕产/用药/疾病/过敏）一律引导营养师判断，不给方案建议。
- 客户检测数据仅用于当次解读，不保存。
