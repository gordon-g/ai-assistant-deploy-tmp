#!/bin/bash
# ============================================================
#  原地升级脚本：把服务器上的旧版后端替换为最新版
#  特点：不重装系统、不动 Nginx 现有站点，只替换应用目录 + 重启服务
#  用法（在服务器上，新包解压目录内执行）：
#     bash upgrade.sh
#  可选环境变量：
#     APP_DIR=/opt/precision-nutrition   # 应用安装目录（默认自动探测）
#     PORT=8000                          # 后端监听端口
# ============================================================

set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok(){ echo -e "${GREEN}✅ $1${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $1${NC}"; }
err(){ echo -e "${RED}❌ $1${NC}"; }

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-8000}"
STAMP=$(date +%Y%m%d_%H%M%S)

echo "=================================================="
echo "  4P 精准营养 AI 助手 · 原地升级"
echo "  源目录: $SRC_DIR"
echo "=================================================="

# ---------- 1. 探测现有部署 ----------
echo ""
echo "[1/6] 探测现有部署..."
APP_DIR="${APP_DIR:-}"

if [ -z "$APP_DIR" ]; then
  # 从正在运行的进程里找 uvicorn app:app 的工作目录
  PID=$(pgrep -f "uvicorn app:app" | head -1 || true)
  if [ -n "$PID" ]; then
    APP_DIR=$(readlink -f "/proc/$PID/cwd" 2>/dev/null | sed 's#/backend$##' || true)
    echo "    从运行进程探测到: $APP_DIR (PID=$PID)"
  fi
fi

if [ -z "$APP_DIR" ] || [ ! -d "$APP_DIR" ]; then
  # 常见位置兜底
  for d in /opt/precision-nutrition-assistant /opt/ai-assistant /root/ai-assistant \
           /www/ai-assistant /var/www/ai-assistant /srv/ai-assistant; do
    if [ -f "$d/backend/app.py" ]; then APP_DIR="$d"; break; fi
  done
fi

if [ -z "$APP_DIR" ] || [ ! -d "$APP_DIR" ]; then
  warn "未能自动定位旧应用目录。"
  echo "    请手动指定后重试，例如："
  echo "    APP_DIR=/你的旧目录 bash upgrade.sh"
  echo ""
  echo "    快速定位命令："
  echo "    grep -rn 'uvicorn\\|app:app' /etc/nginx/ /etc/systemd/system/ 2>/dev/null | head"
  exit 1
fi
ok "应用目录: $APP_DIR"

# ---------- 2. 备份 ----------
echo ""
echo "[2/6] 备份旧版本..."
BAK="${APP_DIR}.bak.${STAMP}"
cp -a "$APP_DIR" "$BAK"
ok "已备份到: $BAK"

# ---------- 3. 保留旧配置（关键：避免覆盖已有 Key）----------
echo ""
echo "[3/6] 保留旧配置..."
OLD_CFG="$APP_DIR/config.json"
KEY_BACKUP=""
if [ -f "$OLD_CFG" ]; then
  KEY_BACKUP=$(python3 -c "import json;print(json.load(open('$OLD_CFG'))['llm'].get('api_key',''))" 2>/dev/null || echo "")
fi

# ---------- 4. 替换文件 ----------
echo ""
echo "[4/6] 替换为最新版..."
for item in backend frontend data config.json requirements.txt start.sh deploy.sh install.sh; do
  if [ -e "$SRC_DIR/$item" ]; then
    rm -rf "${APP_DIR:?}/$item"
    cp -a "$SRC_DIR/$item" "$APP_DIR/$item"
  fi
done
# 清掉旧 pycache，避免 .pyc 冲突
find "$APP_DIR" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
ok "文件已替换"

# ---------- 5. 恢复 Key + 装依赖 ----------
echo ""
echo "[5/6] 恢复配置并安装依赖..."
if [ -n "$KEY_BACKUP" ] && [ "$KEY_BACKUP" != "YOUR_API_KEY_HERE" ]; then
  python3 - "$APP_DIR/config.json" "$KEY_BACKUP" <<'PY'
import json,sys
p,k=sys.argv[1],sys.argv[2]
c=json.load(open(p)); c['llm']['api_key']=k
json.dump(c,open(p,'w'),ensure_ascii=False,indent=2)
print('已恢复原有 API Key')
PY
  ok "已保留原有混元 Key"
else
  warn "未发现已配置的 Key（稍后手动填 config.json 的 llm.api_key）"
fi

python3 -m pip install -q -r "$APP_DIR/requirements.txt" 2>&1 | tail -2 || \
  python3 -m pip install -q --break-system-packages -r "$APP_DIR/requirements.txt" 2>&1 | tail -2
ok "依赖就绪"

# ---------- 6. 重启服务 ----------
echo ""
echo "[6/6] 重启服务..."
SERVICE=$(systemctl list-units --type=service --all 2>/dev/null | grep -iE "precision|nutrition|assistant|uvicorn" | awk '{print $1}' | head -1 || true)

if [ -n "$SERVICE" ]; then
  echo "    重启 systemd 服务: $SERVICE"
  systemctl restart "$SERVICE"
  ok "服务已重启"
elif [ -n "${PID:-}" ]; then
  echo "    检测到裸进程 PID=$PID，重启中..."
  kill "$PID" 2>/dev/null || true
  sleep 2
  cd "$APP_DIR/backend"
  nohup python3 -m uvicorn app:app --host 0.0.0.0 --port "$PORT" \
    > "$APP_DIR/app.log" 2>&1 &
  ok "已以裸进程方式重启（日志: $APP_DIR/app.log）"
else
  warn "未找到运行中的服务。手动启动："
  echo "    cd $APP_DIR/backend && nohup python3 -m uvicorn app:app --host 0.0.0.0 --port $PORT &"
fi

# ---------- 自检 ----------
echo ""
echo "自检中..."
sleep 4
if curl -s -m 5 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
  HEALTH=$(curl -s -m 5 "http://127.0.0.1:${PORT}/api/health")
  echo ""
  echo "=================================================="
  ok "升级成功！"
  echo "=================================================="
  echo "  健康详情: $HEALTH"
  echo ""
  echo "  若健康里 cloud_ok=false，请填混元 Key："
  echo "    编辑 $APP_DIR/config.json 里的 llm.api_key"
  echo "    然后 systemctl restart ${SERVICE:-precision-nutrition-assistant}"
  echo ""
  echo "  回滚（如需）："
  echo "    rm -rf $APP_DIR && mv $BAK $APP_DIR && systemctl restart ${SERVICE:-precision-nutrition-assistant}"
else
  err "新服务未正常响应，最近日志："
  if [ -n "${SERVICE:-}" ]; then journalctl -u "$SERVICE" -n 30 --no-pager; else tail -30 "$APP_DIR/app.log" 2>/dev/null; fi
  echo ""
  echo "  回滚命令：rm -rf $APP_DIR && mv $BAK $APP_DIR && systemctl restart ${SERVICE:-precision-nutrition-assistant}"
fi
