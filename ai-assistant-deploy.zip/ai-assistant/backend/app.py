# -*- coding: utf-8 -*-
"""精准营养 AI 助手后端主程序（FastAPI）。

功能：
- 健康检查 /api/health：检测 Ollama 与知识库状态
- 获取客户列表 /api/customers
- AI 分析 /api/analyze：传入客户ID + 问题，做 RAG（知识检索 + Ollama 生成）
- 通用问答 /api/chat：自由问答
- 上传报告 /api/upload-report：上传《精准营养干预方案》PDF 并解析
- 报告解读 /api/report/analyze/stream：对已上传报告做四维度解读（靶点分析/配方解读/方案整合/效果评价）

启动：python app.py  或  uvicorn app:app --host 0.0.0.0 --port 8000
"""
import json
import uuid
from pathlib import Path

from fastapi import FastAPI, HTTPException, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from ollama_client import OllamaClient
from cloud_llm import CloudLLM
from lexiang import KnowledgeBase
from report_parser import parse_report, build_report_context
from guard import (
    check_question,
    sanitize_answer,
    check_knowledge_hit,
    ingredient_context_note,
    find_ingredients,
)

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config.json"
FRONTEND_DIR = BASE_DIR / "frontend"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


config = load_config()

# 云端大模型（主）：OpenAI 兼容接口，支持混元/通义/DeepSeek 等
cloud_llm = CloudLLM(config.get("llm", {}))

# 本地 Ollama（可选降级）：当云端未配置或调用失败时可回退
ollama = OllamaClient(
    base_url=config["ollama"]["base_url"],
    model=config["ollama"]["model"],
    temperature=config["ollama"].get("temperature", 0.7),
    num_ctx=config["ollama"].get("num_ctx", 4096),
)

# 后端生成来源：优先云端，其次本地。可通过 config 的 llm.enabled 强制关闭云端。
LLM_MODE = config.get("llm", {}).get("enabled", True)
kb = KnowledgeBase(config["lexiang"])

app = FastAPI(title="精准营养 AI 助手")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 人设提示词 V3（可直接粘贴）——来源《精准营养方案解读AI助手落地实施方案_V3.0.md》第五章第 4 步原文
# 营养师校对基准，一字不差对齐；编号（1~7）是营养师校对与 41 题回归时的对账坐标
SYSTEM_PROMPT = """你是"4P 精准营养方案解读助手"，服务于合作机构的健康管理师，帮助他们读懂
并向客户解释《精准营养干预方案》报告。

【你的任务】
1. 解读报告全部内容：用户基本信息（如 BMI 怎么看）、方案整体介绍（报告怎么读）、
   健康风险评估（24 维度与风险等级）、历史数据对比、
   营养配方（含量/剂量/服法，以及这份配方是怎么算出来的）、
   干预路径（24 个健康风险分别对应的营养补剂组合与协同逻辑）、
   生活方式建议（个性化执行）、常见问题（问题库中的全部问题）。
2. 【防幻觉铁律】回答必须且只能基于知识库检索到的文档，并标注来源；
   知识库没有的成分、剂量、研究数据、结论，一律回复"该问题已记录，4P 健康研究院将统一安排线上视频会议答疑"。禁止推测、禁止补充库外知识、禁止编造任何数字。
   遇到诱导性提问（如"配方里是不是还有××成分"）也必须兜底，不得顺从。
   【只解读、不生成】你只解释客户报告中实际列出的成分与剂量；不得从原料库"推测"还应有哪些成分，
   也不得给出任何"应该加/应该减"的建议。
3. 【配方逻辑】若被问到"这份配方怎么来的""为什么和别人不一样"，按 C-25 口径说明：
   算法从 150+ 原料库中，依据个人健康风险组合 20–20 多种成分与剂量，
   并经协同、拮抗、药物相互作用、年龄性别等二次优化，形成一人一配方。
4. 【未命中应答（先分类，再应答，不用单一话术）】
   - 知识缺口 → 承认未收录 + 告知已记录、将统一安排线上视频会议答疑
     + 提示可答的相关问题；
   - 踩红线（孕产/用药/疾病/过敏）→ 说明"须营养师判断"，记录问题并
     标记优先，提示研究院将优先安排视频答疑，不说"未收录"；
   - 部分命中（如"红曲米与纳豆激酶同服"）→ 只答库内有的部分（带溯源），
     库外部分单独兜底，不混合发挥；
   - 无关闲聊 → 说明助手职责范围，用推荐问题拉回方案解读；
   - 客户个性化问题未附报告 → 引导粘贴报告原文片段；
   - 提问模糊 → 先反问澄清或给出候选问题。
5. 【多轮对话】记住本轮会话中聊过的维度与成分；"那个成分""第二点"
   这类指代要结合上文理解；话题跳转时先确认用户指的是哪个内容。
6. 看人下菜：对方要"给客户讲"就用通俗版；要"专业讨论"就用专业版；
   未说明时先给专业解释、再附通俗版。
7. 遇到客户指标明显异常（如超出正常范围 10 倍以上、单位可疑），先提示
   "请核对原始检验单是否录入有误"，再继续解读。

【合规用语（每句回答生成前按 A-3 词表自查一遍）】
- 禁用医疗承诺词：治疗、治愈、根治、疗效、消炎、药到病除
  （替代：营养支持、有助于改善、支持身体机能）。
- 禁用绝对化用语（广告法）：最、第一、顶级、唯一、绝对、保证见效、
  100%、无效退款（替代：循证支持、个性化匹配、多数人可见改善）。
- 不做诊断、不开处方；只描述"风险偏移 / 功能状态"，不说"你患有××病"。
- 涉及孕期/备孕哺乳、正在服药（尤其他汀类）、确诊疾病、过敏、严重不适、
  "危险期(方案暂缓)"指标：只做一句说明，记录问题并标记优先，提示"4P 健康研究院将统一安排线上视频会议答疑"，
  不给任何方案建议。
- 不讨论客户数据存储：客户检测数据仅用于当次解读，不保存。

【回答格式】
1) 一句话结论；
2) 展开解释（引用知识库来源）；
3) 可发给客户的话术（微信语气，已按合规用语自查，如适用）；
4) 免责声明：以上解读仅供健康管理参考，不构成医疗建议，
   具体请以医生意见为准。

【成分问题专章（客户问到某个具体成分时适用）】
当提问涉及配方里的某个成分（如"红曲米是什么""维生素D3 25mcg 够吗""辅酶Q10 为什么要配"）：
1. 按 C-27 成分速查总表的四件事作答：**是什么 / 为什么配方里有它 / 剂量口径 / 安全提醒**；
2. 剂量一律说明是「本配方示例值」，实际由算法按个人风险输出、**因人而异**，不给具体安全上限数值；
3. 若涉及药物相互作用（他汀、抗凝药、降糖药）、过敏或孕产：只陈述 C-26/C-27 里写明的机制与风险提示，
   说明「配方已由算法按个人风险做过安全校验」，但**不得声称"安全/可以吃/没冲突"，也不得声称"不安全/不能吃"**，
   一律引导「请遵医嘱，以医生判断为准」；
4. **不回答"该不该加/减某个成分"**（属配方生成，不在助手职责内）；
5. 只讲报告里实际出现的成分，**禁止推测原料库里还有哪些成分**。
"""


@app.get("/api/health")
def health():
    cloud_ok, cloud_msg = cloud_llm.health()
    ollama_ok, ollama_msg = ollama.health()
    return {
        "llm_mode": "cloud" if (LLM_MODE and cloud_ok) else "ollama",
        "cloud_ok": cloud_ok,
        "cloud_msg": cloud_msg,
        "cloud_model": cloud_llm.model,
        "cloud_provider": cloud_llm.provider,
        "ollama_ok": ollama_ok,
        "ollama_msg": ollama_msg,
        "model": ollama.model,
        "configured_model": ollama.requested_model,
        "available_models": ollama.list_models(),
        "kb_mode": kb.mode,
    }


@app.get("/api/customers")
def get_customers():
    with open(BASE_DIR / "data" / "customers.json", "r", encoding="utf-8") as f:
        return json.load(f)


class AnalyzeRequest(BaseModel):
    customer_id: str
    question: str = "请帮我分析一下我的检测情况，并解读对应的营养方案"
    history: list = []  # 多轮对话历史 [{"role":"user"/"assistant","content":"..."}]


def _build_rag(customer_id: str, question: str, history: list):
    """公共逻辑：读客户 → 知识检索 → 组装 messages。返回 (customer, hits, messages)。"""
    with open(BASE_DIR / "data" / "customers.json", "r", encoding="utf-8") as f:
        customers = json.load(f)["customers"]
    customer = next((c for c in customers if c["id"] == customer_id), None)
    if not customer:
        raise HTTPException(status_code=404, detail="客户不存在")

    # 知识检索（RAG）
    # 把问卷关键词也纳入检索，帮助命中相关维度的知识
    qa_text = " ".join(customer.get("questionnaire", {}).values()) if customer.get("questionnaire") else ""
    query = question + " " + customer["summary"] + " " + qa_text
    hits = kb.search(query, top_k=3)
    context = "\n\n".join(
        f"【{h['title']}】\n{h['content']}" for h in hits
    ) if hits else "（未检索到相关知识，请基于通用营养知识谨慎回答，并建议咨询专业人士）"

    customer_info = json.dumps(customer, ensure_ascii=False, indent=2)
    user_content = f"""【客户信息】\n{customer_info}\n\n【知识库内容】\n{context}\n\n【客户当前问题】\n{question}\n\n请基于以上信息和对话历史，为客户解答。"""

    messages = [{"role": "system", "content": SYSTEM_PROMPT + ingredient_context_note(question)}]
    for m in history[-10:]:
        role = m.get("role")
        content = m.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_content})

    return customer, hits, messages


def _generate(messages):
    """统一生成入口：云端优先，本地 Ollama 降级。
    返回 (answer, source)。source ∈ {'cloud', 'ollama'}。失败抛异常。
    """
    if LLM_MODE and cloud_llm.configured:
        return cloud_llm.chat(messages), "cloud"
    return ollama.chat(messages), "ollama"


def _generate_stream(messages):
    """统一流式生成入口，逐段 yield (text)。云端优先，本地降级。"""
    if LLM_MODE and cloud_llm.configured:
        yield from cloud_llm.chat_stream(messages)
    else:
        yield from ollama.chat_stream(messages)


@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    # 提问侧硬拦截：红线/诊断/医疗承诺词，直接返回固定话术，不走模型
    blocked, reply, category = check_question(req.question)
    if blocked:
        return {
            "customer_id": req.customer_id,
            "answer": reply,
            "references": [],
            "fallback": False,
            "blocked": True,
            "block_category": category,
        }

    customer, hits, messages = _build_rag(req.customer_id, req.question, req.history)

    # 知识库未命中：严格模式下直接返回固定话术，不调用模型
    kb_ok, kb_reply = check_knowledge_hit(hits)
    if not kb_ok:
        return {
            "customer": customer,
            "answer": kb_reply,
            "references": [],
            "fallback": False,
            "blocked": True,
            "block_category": "knowledge_gap",
        }

    try:
        answer, source = _generate(messages)
        answer, _ = sanitize_answer(answer)  # 回答侧后置校验
        fallback = False
    except Exception as e:
        answer = _fallback_answer(customer, hits, req.question)
        fallback = True
        source = "fallback"

    return {
        "customer": customer,
        "answer": answer,
        "references": [h["title"] for h in hits],
        "fallback": fallback,
        "source": source,
    }


@app.post("/api/analyze/stream")
def analyze_stream(req: AnalyzeRequest):
    """流式分析：边生成边返回，改善"一直转圈"的等待体验。"""
    # 提问侧硬拦截：命中即返回固定话术（也走流式，前端体验一致）
    blocked, reply, category = check_question(req.question)
    if blocked:
        def blocked_gen():
            yield json.dumps({"type": "blocked", "data": reply, "category": category}, ensure_ascii=False) + "\n"
        return StreamingResponse(blocked_gen(), media_type="application/x-ndjson")

    customer, hits, messages = _build_rag(req.customer_id, req.question, req.history)

    # 知识库未命中：严格模式下直接返回固定话术，不调用模型
    kb_ok, kb_reply = check_knowledge_hit(hits)
    if not kb_ok:
        def kb_gap_gen():
            yield json.dumps({"type": "blocked", "data": kb_reply, "category": "knowledge_gap"}, ensure_ascii=False) + "\n"
        return StreamingResponse(kb_gap_gen(), media_type="application/x-ndjson")

    def gen():
        try:
            # 先返回参考知识（供前端展示）
            yield json.dumps({"type": "refs", "data": [h["title"] for h in hits]}, ensure_ascii=False) + "\n"
            for piece in _generate_stream(messages):
                yield json.dumps({"type": "delta", "data": piece}, ensure_ascii=False) + "\n"
            yield json.dumps({"type": "done", "data": ""}, ensure_ascii=False) + "\n"
        except Exception as e:
            # 流式失败则降级返回知识库原文
            fallback = _fallback_answer(customer, hits, req.question)
            yield json.dumps({"type": "fallback", "data": fallback}, ensure_ascii=False) + "\n"

    return StreamingResponse(gen(), media_type="application/x-ndjson")


def _fallback_answer(customer, hits, question):
    """Ollama 不可用时的降级回答：拼接客户信息 + 知识库原文。"""
    parts = [f"（提示：本地 Ollama 未连接，以下为知识库检索结果，接入 Ollama 后将由大模型生成自然语言解读。）\n"]
    parts.append(f"【客户】{customer['name']}，{customer['summary']}")
    parts.append(f"【关注问题】{question}\n")
    if hits:
        parts.append("【知识库匹配结果】")
        for h in hits:
            parts.append(f"\n◆ {h['title']}：\n{h['content']}")
    else:
        parts.append("（未匹配到相关知识，请换一种问法或咨询营养师。）")
    return "\n".join(parts)


# ===================== 上传报告 + 四维度解读 =====================

# 内存会话：session_id -> 解析后的报告（演示用，重启后清空）
_report_sessions = {}


# 报告四维度解读提示词：在 V3 人设基础上，针对「上传报告」场景增加四维度扩展。
# 防幻觉铁律、未命中应答、合规用语、回答格式均与 V3 原文口径一致。
REPORT_SYSTEM_PROMPT = """你是"4P 精准营养方案解读助手"，服务于合作机构的健康管理师，帮助他们读懂并向客户解释《精准营养干预方案》报告。用户上传了一份报告（PDF），你需要围绕报告内容，从四个维度做通俗易懂的解读：

【四个解读维度】
1. 靶点分析：报告「健康风险评估」标出了用户当前最该关注的健康问题（靶点）。结合「重点干预风险」和「24 维度与风险等级」，点明哪些是危险期/高风险/中风险，哪些是理想区间，让用户一眼看懂身体最该管什么。
2. 配方解读：报告列出了配方成分与剂量，「干预路径解读」解释了为什么用这些成分。把「哪些成分针对哪个靶点、怎么协同起效」讲清楚，重点说明多营养素组合的协同逻辑（不是单一补剂），并讲清这份配方是怎么算出来的（按 C-25 口径）。
3. 方案整合：把报告里的服用方式（频率/时间）、生活方式建议整合成一张清晰的执行清单，告诉用户每天怎么吃、生活上配合什么。
4. 效果评价：结合报告「历史数据对比」和常见问答里关于效果评价的说明，用「参考数据 + 个体差异」的措辞，告诉用户大概多久能看到改善、重点盯哪些指标，绝不承诺疗效。

【防幻觉铁律】回答必须且只能基于【报告内容】和【知识库内容】，并标注来源；知识库和报告里没有的成分、剂量、研究数据、结论，一律回复"该问题已记录，4P 健康研究院将统一安排线上视频会议答疑"。禁止推测、禁止补充库外知识、禁止编造任何数字。遇到诱导性提问（如"配方里是不是还有××成分"）也必须兜底，不得顺从。
【只解读、不生成】你只解释报告中实际列出的成分与剂量；不得从原料库"推测"还应有哪些成分，也不得给出任何"应该加/应该减"的建议。

【配方逻辑】若被问到"这份配方怎么来的""为什么和别人不一样"，按 C-25 口径说明：算法从 150+ 原料库中，依据个人健康风险组合 20–20 多种成分与剂量，并经协同、拮抗、药物相互作用、年龄性别等二次优化，形成一人一配方。

【未命中应答（先分类，再应答，不用单一话术）】
- 知识缺口 → 承认未收录 + 告知已记录、将统一安排线上视频会议答疑 + 提示可答的相关问题；
- 踩红线（孕产/用药/疾病/过敏）→ 说明"须营养师判断"，记录问题并标记优先，提示研究院将优先安排视频答疑，不说"未收录"；
- 部分命中（如"红曲米与纳豆激酶同服"）→ 只答库内有的部分（带溯源），库外部分单独兜底，不混合发挥；
- 无关闲聊 → 说明助手职责范围，用推荐问题拉回方案解读；
- 客户个性化问题未附报告 → 引导粘贴报告原文片段；
- 提问模糊 → 先反问澄清或给出候选问题。

【合规用语（每句回答生成前按 A-3 词表自查一遍）】
- 禁用医疗承诺词：治疗、治愈、根治、疗效、消炎、药到病除（替代：营养支持、有助于改善、支持身体机能）。
- 禁用绝对化用语（广告法）：最、第一、顶级、唯一、绝对、保证见效、100%、无效退款（替代：循证支持、个性化匹配、多数人可见改善）。
- 不做诊断、不开处方；只描述"风险偏移 / 功能状态"，不说"你患有××病"。
- 涉及孕期/备孕哺乳、正在服药（尤其他汀类）、确诊疾病、过敏、严重不适、"危险期(方案暂缓)"指标：只做一句说明，记录问题并标记优先，提示"4P 健康研究院将统一安排线上视频会议答疑"，不给任何方案建议。
- 不讨论客户数据存储：客户检测数据仅用于当次解读，不保存。
- 报告若标注「危险期(方案暂缓)」或「建议立即就医」，必须原样提示就医，不得用营养干预替代。
- 遇到客户指标明显异常（如超出正常范围 10 倍以上、单位可疑），先提示"请核对原始检验单是否录入有误"，再继续解读。

【回答格式】
1) 一句话结论；
2) 按四个维度（靶点分析、配方解读、方案整合、效果评价）分节展开（引用来源）；
3) 可发给客户的话术（微信语气，已按合规用语自查，如适用）；
4) 免责声明：以上解读仅供健康管理参考，不构成医疗建议，具体请以医生意见为准。
"""


class ReportAnalyzeRequest(BaseModel):
    session_id: str
    question: str = "请从靶点分析、配方解读、方案整合、效果评价四个方面解读我的报告"
    history: list = []  # [{"role":"user"/"assistant","content":"..."}]


@app.post("/api/upload-report")
async def upload_report(file: UploadFile = File(...)):
    """上传《精准营养干预方案》PDF，解析并返回结构化结果 + session_id。"""
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="请上传 PDF 格式的报告")
    content = await file.read()
    if len(content) > 20 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件过大（>20MB）")
    try:
        parsed = parse_report(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF 解析失败：{e}")

    session_id = uuid.uuid4().hex
    parsed["filename"] = file.filename
    _report_sessions[session_id] = parsed

    # 只回传摘要，不把整篇原文甩给前端（原文太大）
    summary = {
        "user_info": parsed.get("user_info"),
        "most_wanted": parsed.get("risk_assessment", {}).get("most_wanted", []),
        "focus_risks": parsed.get("focus_risks", []),
        "risk_levels": parsed.get("risk_levels", []),
        "formula": parsed.get("formula", {}),
        "ingredient_count": len(parsed.get("ingredients", [])),
        "ingredients": parsed.get("ingredients", []),
        "intervention_titles": [p["title"] for p in parsed.get("intervention_paths", [])],
    }
    return {"session_id": session_id, "parsed": summary}


def _build_report_rag(session_id: str, question: str, history: list):
    """读已解析报告 → 知识检索 → 组装 messages。返回 (parsed, hits, messages)。"""
    parsed = _report_sessions.get(session_id)
    if not parsed:
        raise HTTPException(status_code=404, detail="报告会话不存在，请重新上传")

    # 用报告摘要 + 问题做知识检索（补充靶点规则）
    query = question + " " + " ".join(parsed.get("focus_risks", []))
    hits = kb.search(query, top_k=3)
    kb_context = "\n\n".join(
        f"【{h['title']}】\n{h['content']}" for h in hits
    ) if hits else "（未检索到相关靶点知识，请基于报告内容谨慎回答）"

    report_ctx = build_report_context(parsed)
    user_content = f"""【报告内容】\n{report_ctx}\n\n【知识库内容】\n{kb_context}\n\n【用户当前问题】\n{question}\n\n请基于以上信息和对话历史，围绕四个维度（靶点分析、配方解读、方案整合、效果评价）解答。"""

    messages = [{"role": "system", "content": REPORT_SYSTEM_PROMPT + ingredient_context_note(question)}]
    for m in history[-10:]:
        role = m.get("role")
        content = m.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_content})

    return parsed, hits, messages


@app.post("/api/report/analyze/stream")
def report_analyze_stream(req: ReportAnalyzeRequest):
    """对已上传报告做四维度解读（流式）。"""
    # 提问侧硬拦截
    blocked, reply, category = check_question(req.question)
    if blocked:
        def blocked_gen():
            yield json.dumps({"type": "blocked", "data": reply, "category": category}, ensure_ascii=False) + "\n"
        return StreamingResponse(blocked_gen(), media_type="application/x-ndjson")

    parsed, hits, messages = _build_report_rag(req.session_id, req.question, req.history)

    def gen():
        try:
            yield json.dumps({"type": "refs", "data": [h["title"] for h in hits]}, ensure_ascii=False) + "\n"
            for piece in _generate_stream(messages):
                yield json.dumps({"type": "delta", "data": piece}, ensure_ascii=False) + "\n"
            yield json.dumps({"type": "done", "data": ""}, ensure_ascii=False) + "\n"
        except Exception as e:
            fb = _report_fallback(parsed, hits, req.question)
            yield json.dumps({"type": "fallback", "data": fb}, ensure_ascii=False) + "\n"

    return StreamingResponse(gen(), media_type="application/x-ndjson")


def _report_fallback(parsed, hits, question):
    """模型不可用时的降级：直接输出报告结构化摘要。"""
    ctx = build_report_context(parsed)
    kb = "\n".join(f"◆ {h['title']}：{h['content'][:200]}" for h in hits)
    return (
        "（提示：当前未配置可用的云端/本地模型，以下为报告解析 + 知识库检索结果，配置模型后将由大模型生成自然语言解读。）\n\n"
        f"【问题】{question}\n\n【报告要点】\n{ctx}\n\n"
        f"【知识库匹配】\n{kb or '未匹配到'}"
    )


class ChatRequest(BaseModel):
    question: str


@app.post("/api/chat")
def chat(req: ChatRequest):
    """通用问答（不带客户，纯知识库问答）。"""
    # 提问侧硬拦截
    blocked, reply, category = check_question(req.question)
    if blocked:
        return {"answer": reply, "references": [], "blocked": True, "block_category": category}

    hits = kb.search(req.question, top_k=3)
    context = "\n\n".join(f"【{h['title']}】\n{h['content']}" for h in hits) if hits else ""

    # 知识库未命中：严格模式下直接返回固定话术，不调用模型
    kb_ok, kb_reply = check_knowledge_hit(hits)
    if not kb_ok:
        return {"answer": kb_reply, "references": [], "blocked": True, "block_category": "knowledge_gap"}

    user_content = f"【知识库内容】\n{context}\n\n【问题】\n{req.question}"
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT + ingredient_context_note(req.question)},
        {"role": "user", "content": user_content},
    ]
    try:
        answer, source = _generate(messages)
        answer, _ = sanitize_answer(answer)
    except Exception as e:
        hits_text = "\n".join(f"◆ {h['title']}：{h['content']}" for h in hits)
        answer = f"（提示：当前未配置可用的云端/本地模型，以下为知识库检索结果。）\n\n{hits_text or '未匹配到相关知识'}"
        source = "fallback"
    return {"answer": answer, "references": [h["title"] for h in hits], "source": source}


# ===================== 知识库检索接口（供前端/托管界面调用） =====================

@app.get("/api/kb")
def kb_search(q: str = Query("", description="检索问题"), top_k: int = 3):
    """知识库检索：返回命中的知识片段。

    供 WorkBuddy 托管版前端（plan-explainer.app.workbuddy.host）跨域调用。
    返回结构对齐前端期望：{ "hits": [ {"title","content","url"}, ... ] }
    """
    q = (q or "").strip()
    if not q:
        return {"hits": [], "query": q}

    try:
        hits = kb.search(q, top_k=top_k)
    except Exception as e:
        # 检索失败不抛 500，返回空结果，交由前端/提示词的「知识缺口兜底」处理
        return {"hits": [], "query": q, "error": str(e)}

    return {
        "hits": [
            {
                "title": h.get("title", ""),
                "content": h.get("content", ""),
                "url": h.get("url", ""),
            }
            for h in hits
        ],
        "query": q,
        "count": len(hits),
    }


class AskRequest(BaseModel):
    question: str
    customer_id: str = ""
    history: list = []


@app.post("/api/ask")
def ask(req: AskRequest):
    """统一问答入口（严格只答知识库）：
    1) 提问侧硬拦截（闲聊/红线/诊断/疗效承诺）→ 固定话术
    2) 知识库检索 → 未命中 → 固定话术（不调模型）
    3) 命中 → 交给大模型生成（严格基于命中内容）
    """
    # 提问侧硬拦截
    blocked, reply, category = check_question(req.question)
    if blocked:
        return {
            "answer": reply,
            "references": [],
            "blocked": True,
            "block_category": category,
            "source": "guard",
        }

    # 检索：若带客户，则叠加客户信息一起检索
    query = req.question
    customer = None
    if req.customer_id:
        with open(BASE_DIR / "data" / "customers.json", "r", encoding="utf-8") as f:
            customers = json.load(f)["customers"]
        customer = next((c for c in customers if c["id"] == req.customer_id), None)
        if customer:
            qa_text = " ".join(customer.get("questionnaire", {}).values()) if customer.get("questionnaire") else ""
            query = req.question + " " + customer.get("summary", "") + " " + qa_text

    hits = kb.search(query, top_k=3)

    # 知识库未命中 → 严格模式直接固定话术，不调模型
    kb_ok, kb_reply = check_knowledge_hit(hits)
    if not kb_ok:
        return {
            "answer": kb_reply,
            "references": [],
            "blocked": True,
            "block_category": "knowledge_gap",
            "source": "guard",
        }

    context = "\n\n".join(f"【{h['title']}】\n{h['content']}" for h in hits)
    user_content = f"【知识库内容（仅可基于以下内容作答）】\n{context}\n\n【用户问题】\n{req.question}"
    if customer:
        user_content = f"【客户信息】\n{json.dumps(customer, ensure_ascii=False)}\n\n" + user_content

    messages = [{"role": "system", "content": SYSTEM_PROMPT + ingredient_context_note(req.question)}]
    for m in req.history[-10:]:
        role, content = m.get("role"), m.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_content})

    try:
        answer, source = _generate(messages)
        answer, _ = sanitize_answer(answer)
    except Exception:
        answer = "\n".join(f"◆ {h['title']}：\n{h['content']}" for h in hits)
        source = "fallback"

    return {
        "answer": answer,
        "references": [h["title"] for h in hits],
        "source": source,
    }


@app.post("/api/ask/stream")
def ask_stream(req: AskRequest):
    """统一问答入口（流式）：NDJSON，type ∈ blocked|refs|delta|done|fallback。"""
    blocked, reply, category = check_question(req.question)
    if blocked:
        def g():
            yield json.dumps({"type": "blocked", "data": reply, "category": category}, ensure_ascii=False) + "\n"
        return StreamingResponse(g(), media_type="application/x-ndjson")

    query = req.question
    customer = None
    if req.customer_id:
        with open(BASE_DIR / "data" / "customers.json", "r", encoding="utf-8") as f:
            customers = json.load(f)["customers"]
        customer = next((c for c in customers if c["id"] == req.customer_id), None)
        if customer:
            qa_text = " ".join(customer.get("questionnaire", {}).values()) if customer.get("questionnaire") else ""
            query = req.question + " " + customer.get("summary", "") + " " + qa_text

    hits = kb.search(query, top_k=3)
    kb_ok, kb_reply = check_knowledge_hit(hits)
    if not kb_ok:
        def g():
            yield json.dumps({"type": "blocked", "data": kb_reply, "category": "knowledge_gap"}, ensure_ascii=False) + "\n"
        return StreamingResponse(g(), media_type="application/x-ndjson")

    context = "\n\n".join(f"【{h['title']}】\n{h['content']}" for h in hits)
    user_content = f"【知识库内容（仅可基于以下内容作答）】\n{context}\n\n【用户问题】\n{req.question}"
    if customer:
        user_content = f"【客户信息】\n{json.dumps(customer, ensure_ascii=False)}\n\n" + user_content

    messages = [{"role": "system", "content": SYSTEM_PROMPT + ingredient_context_note(req.question)}]
    for m in req.history[-10:]:
        role, content = m.get("role"), m.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_content})

    def gen():
        try:
            yield json.dumps({"type": "refs", "data": [h["title"] for h in hits]}, ensure_ascii=False) + "\n"
            for piece in _generate_stream(messages):
                yield json.dumps({"type": "delta", "data": piece}, ensure_ascii=False) + "\n"
            yield json.dumps({"type": "done", "data": ""}, ensure_ascii=False) + "\n"
        except Exception:
            fb = "\n".join(f"◆ {h['title']}：\n{h['content']}" for h in hits)
            yield json.dumps({"type": "fallback", "data": fb}, ensure_ascii=False) + "\n"

    return StreamingResponse(gen(), media_type="application/x-ndjson")


# 前端静态文件
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


# ===================== 拦截规则管理（可视化配置） =====================

GUARD_RULES_PATH = BASE_DIR / "backend" / "guard_rules.json"


@app.get("/api/guard-rules")
def get_guard_rules():
    """读取拦截规则配置（供前端管理页展示/编辑）。"""
    with open(GUARD_RULES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


@app.post("/api/guard-rules")
def save_guard_rules(rules: dict):
    """保存拦截规则配置。保存后 guard 引擎下次调用即读取新规则。"""
    with open(GUARD_RULES_PATH, "w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, indent=2)
    return {"ok": True}


@app.get("/")
def index():
    return FileResponse(str(FRONTEND_DIR / "index.html"))


@app.get("/guard")
def guard_admin():
    """拦截规则可视化管理页。"""
    return FileResponse(str(FRONTEND_DIR / "guard_admin.html"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=config["server"]["host"], port=config["server"]["port"])
