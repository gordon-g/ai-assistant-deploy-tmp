# -*- coding: utf-8 -*-
"""回答边界守卫：代码层硬拦截（不经过模型，100% 可控）。

职责：在提问进入模型前做「提问侧拦截」，在模型产出后做「回答侧校验」。
命中规则 → 直接返回固定话术，绝不让模型自由发挥。

⚠️ 重要：所有「哪些词触发、触发后说什么话」都配置在 **guard_rules.json** 里，
    「哪些成分名要放行」配置在 **ingredients.json** 里。
    你可以直接编辑这两个 JSON 文件来增删触发词、修改话术模板、增补成分别名，
    不用改本代码。改完保存，重启后端生效。

本文件只负责「读配置 + 执行匹配逻辑」，不含任何业务规则。

【成分白名单放行逻辑（v1.3 新增）】
提问中若出现 ingredients.json 里登记的成分名/别名，则优先按「成分问题」放行：
  - 闲聊类、危险期  → 仍然拦截（与成分无关，或属安全底线）
  - 诊断类、疗效承诺 → 放行，由模型按 C-27 合规口径作答（不做诊断、不做承诺）
  - 红线-用药/过敏/孕产/疾病 → 放行，由模型只陈述 C-27 写明的机制与风险提示，
                              不下「安全/不安全」结论，引导遵医嘱
放行时会给提示词追加一段「成分问题作答约束」，确保模型不越界。
"""
import json
import re
from pathlib import Path

_DIR = Path(__file__).resolve().parent
_RULES_PATH = _DIR / "guard_rules.json"
_INGREDIENTS_PATH = _DIR / "ingredients.json"


def _load_rules():
    with open(_RULES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_ingredients():
    try:
        with open(_INGREDIENTS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"成分白名单": [], "泛称": {"词": []}}


def _split_words(s):
    """把逗号分隔的字符串拆成词列表（去空、去空格）。"""
    if not s:
        return []
    return [w.strip() for w in s.split(",") if w.strip()]


def _hit_any(text, words):
    return any(w in text for w in words)


def _hit_category(text, redline_map):
    """在红线类里找出命中的第一个子类别名（如「用药」），未命中返回 None。"""
    for cat, words_str in redline_map.items():
        words = _split_words(words_str)
        if any(w in text for w in words):
            return cat
    return None


# ===================== 成分白名单 =====================

def _alias_hit(q_lower, alias):
    """判断别名是否命中，规避短英文别名的误伤。

    规则：
    - 中文别名：直接子串匹配（中文无词边界，安全）。
    - 纯英文/数字别名：
        * 长度 >= 5 → 子串匹配（如 "Thiamine"、"Silymarin"）；
        * 长度 2-4 且是常见缩写（VA/VC/VB1/DIM/GABA/DHA/NR/PS…）→ 要求前后不粘连拉丁字母，
          避免 "VA" 命中 "value"、"NR" 命中 "energy"；
        * 长度 2-4 且是普通英文单词（Zinc/Iron/Sage/Hops/Kava/Lime/Maca）→ 要求完整单词边界，
          避免 "iron" 命中 "environment"。
    """
    a = (alias or "").strip()
    if not a:
        return False
    al = a.lower()
    if not al:
        return False
    if not al.isascii():
        return al in q_lower
    if len(al) >= 5:
        return al in q_lower
    # 短英文：要求两侧不是英文字母（数字/中文/空格/标点都算边界）
    m = re.search(r"(?<![a-z])" + re.escape(al) + r"(?![a-z])", q_lower)
    return bool(m)


def find_ingredients(question):
    """在提问中查找命中的成分（含别名）。

    返回 [(标准名, 命中的原文词), ...]，按命中的原文词长度降序（长词优先）。
    同一成分只记一次，记最长命中词（便于前端提示「你是问 XX 吗」）。
    """
    data = _load_ingredients()
    q = question or ""
    ql = q.lower()
    found = []
    for item in data.get("成分白名单", []):
        std = item.get("标准名", "")
        en = item.get("英文名", "")
        candidates = [std] + ([en] if en else []) + list(item.get("别名", []))
        best = None
        for alias in candidates:
            if _alias_hit(ql, alias):
                if best is None or len(alias) > len(best):
                    best = alias
        if best:
            found.append((std, best))
    found.sort(key=lambda x: -len(x[1]))
    return found


def find_ingredients_strict(question, generic_terms=None):
    """剔除「纯泛称误命中」后的成分命中。

    场景：泛称里登记了「配方」「剂量」「含量」等词，
    当提问只是「这个配方能治好我的糖尿病吗」这类泛称句时，
    子串匹配可能会命中成分别名「VA」（因为 "配方" 拼音无关，但英文片段可能巧合），
    或短别名命中英文长词。此函数只保留「命中词确实出现在中文语境里」的结果：
      - 中文别名 → 保留
      - 英文别名 len>=5 → 保留
      - 英文短别名 → 必须是完整词边界命中（由 _alias_hit 已保证）且该词在原文中独立成词
    """
    hits = find_ingredients(question)
    out = []
    for std, hit in hits:
        a = (hit or "").strip()
        if a and not a.isascii():
            out.append((std, hit))
            continue
        # 英文别名：已通过词边界校验，保留
        out.append((std, hit))
    return out


def _has_any(text, words):
    return any(w and w in text for w in words)


def _category_kind(question):
    """判断提问若【不含成分】时会被归入哪一类（用于「成分是否真的改变判定」）。"""
    rules = _load_rules()
    cats = rules["categories"]
    q = question or ""

    diag_words = _split_words(cats["diagnosis"]["触发词"])
    if _has_any(q, diag_words):
        return "diagnosis"
    redline_map = cats["redline"]["触发词"]
    cat = _hit_category(q, redline_map)
    if cat:
        return "redline:" + cat
    promise_words = _split_words(cats["promise"]["触发词"])
    if _has_any(q, promise_words):
        return "promise"
    chat_words = _split_words(cats["chat"]["触发词"])
    chat_regex = cats["chat"].get("正则", "")
    if _has_any(q, chat_words) or (chat_regex and re.search(chat_regex, q)):
        return "chat"
    return "plain"


def find_generic_terms(question):
    """查找命中的泛称（成分/营养素/剂量等）。"""
    data = _load_ingredients()
    q = (question or "").lower()
    return [w for w in data.get("泛称", {}).get("词", []) if w and w.lower() in q]


def check_question(question):
    """提问侧拦截。

    返回 (blocked, reply, category)
    - blocked: 是否应直接拦截（不走模型）
    - reply: 拦截时返回的固定话术（来自配置模板）
    - category: 拦截类别（chat/redline/diagnosis/promise，未拦截为 None）
    """
    rules = _load_rules()
    cats = rules["categories"]
    templates = rules["templates"]
    q = question or ""

    # ---------- 先判成分：命中成分名/别名则按「成分问题」优先放行 ----------
    ingredient_hits = find_ingredients(q)
    generic_hits = find_generic_terms(q)
    is_ingredient_question = bool(ingredient_hits) or bool(generic_hits)

    if is_ingredient_question:
        chat_words = _split_words(cats["chat"]["触发词"])
        chat_regex = cats["chat"].get("正则", "")
        is_chat = _has_any(q, chat_words) or bool(chat_regex and re.search(chat_regex, q))

        danger_words = _split_words(cats["redline"]["触发词"].get("危险期", ""))
        is_danger = _has_any(q, danger_words)

        # 危险期属安全底线，永远拦
        if is_danger:
            return True, templates["redline"].format(category="危险期"), "redline"
        # 闲聊类永远拦（天气、吃什么、股票…）
        if is_chat:
            return True, templates["chat"], "chat"

        # 其余情形：只有「纯泛称」且原文不含任何成分名时，才交给后面的普通拦截逻辑，
        # 否则一律视为成分类问题放行（诊断/疗效承诺/用药/过敏/孕产/疾病均放行）。
        hit_only_generic = (not ingredient_hits) and bool(generic_hits)
        if not hit_only_generic:
            return False, "", None

    # ---------- 未命中成分 / 纯泛称：走原有硬拦截逻辑 ----------
    # 1. 诊断类（优先于红线「疾病」关键词，避免误归类）
    diag_words = _split_words(cats["diagnosis"]["触发词"])
    if _has_any(q, diag_words):
        return True, templates["diagnosis"], "diagnosis"

    # 2. 红线类（孕产/用药/疾病/过敏/危险期）
    redline_map = cats["redline"]["触发词"]
    cat = _hit_category(q, redline_map)
    if cat:
        return True, templates["redline"].format(category=cat), "redline"

    # 3. 疗效承诺类
    promise_words = _split_words(cats["promise"]["触发词"])
    if _has_any(q, promise_words):
        return True, templates["promise"], "promise"

    # 4. 闲聊类（含正则匹配）
    chat_words = _split_words(cats["chat"]["触发词"])
    chat_regex = cats["chat"].get("正则", "")
    if _has_any(q, chat_words) or (chat_regex and re.search(chat_regex, q)):
        return True, templates["chat"], "chat"

    return False, "", None


def ingredient_context_note(question):
    """若提问命中成分，返回一段追加到提示词的「成分问题作答约束」；否则返回空串。

    这段约束保证：即使放行了用药/过敏/孕产类成分问题，
    模型也只按 C-27/C-26 讲机制与风险提示，不下结论、不给建议。
    """
    hits = find_ingredients(question)
    if not hits:
        if find_generic_terms(question):
            return (
                "\n\n【本次提问涉及营养素成分的口径要求】\n"
                "1. 只依据知识库（尤其 C-27 成分速查总表、C-26 成分与药物相互作用说明）作答，标注来源；\n"
                "2. 剂量一律说明是「本配方示例值」，实际由算法按个人风险输出、因人而异；\n"
                "3. 库中没有的成分、剂量、研究数据，一律回复「该问题已记录，4P 健康研究院将统一安排线上视频会议答疑」，禁止推测；\n"
                "4. 不提供「该不该加/减某个成分」的建议（属配方生成，不在助手职责内）。"
            )
        return ""

    names = "、".join(sorted({std for std, _ in hits}))
    return (
        f"\n\n【本次提问涉及成分：{names}】\n"
        "回答必须遵守以下成分口径：\n"
        "1. 【只讲机制、不下结论】若问题涉及药物相互作用（他汀、抗凝药、降糖药等）、过敏或孕产，"
        "只陈述知识库（C-27 / C-26）里写明的机制与风险提示原文，"
        "明确说明「配方已由算法按个人风险做过安全校验」，但不得声称「安全/可以吃/没冲突」，"
        "也不得声称「不安全/不能吃」——一律引导「请遵医嘱，以医生判断为准」。\n"
        "2. 【剂量口径】剂量一律说明是「本配方示例值」，实际由算法按个人风险输出、因人而异；"
        "不给具体安全上限数值。\n"
        "3. 【不生成配方】只解释报告里为什么有这个成分，不回答「该不该加/减」。\n"
        "4. 【不做诊断、不做疗效承诺】只描述营养支持层面的机制，不说「能治好/能治疗」。\n"
        "5. 【来源标注】每个成分说明后标注知识库来源标题。"
    )


def sanitize_answer(answer):
    """回答侧后置校验：检查模型产出里是否漏出禁用词/诊断表述。
    返回 (answer, flagged)。命中则追加一段合规兜底说明（不删除原文，避免截断语义）。
    """
    rules = _load_rules()
    check_words = rules["回答侧校验词"]
    check_replies = rules["回答侧校验话术"]

    flagged = False
    a = answer or ""

    # 按配置顺序：诊断类表述 → 医疗承诺词 → 绝对化用语
    for key, reply in check_replies.items():
        words = _split_words(check_words.get(key, ""))
        if words and _hit_any(a, words):
            a += reply
            flagged = True

    return a, flagged


# 供外部直接引用的未命中话术（从配置读取）
def knowledge_gap_reply():
    return _load_rules()["templates"].get("knowledge_gap", "")


def strict_kb_enabled():
    """是否开启「严格只答知识库内容」开关。"""
    return bool(_load_rules().get("严格只答知识库", {}).get("开启", False))


def check_knowledge_hit(hits):
    """知识库检索后判断：是否命中可用内容。
    返回 (ok, reply)。
    - ok=True：检索到**有效**内容，可继续交给模型。
    - ok=False：检索为空 / 严格模式下无有效内容 → 返回固定话术，不调用模型。

    严格模式（guard_rules.json 的「严格只答知识库.开启」）下：
    不仅要求检索有结果，还要求结果里**至少有一条有实质正文**（去空白后长度 >= 阈值），
    避免「命中但内容为空」时模型凭空发挥。
    """
    # 过滤出「有实质正文」的命中
    valid = []
    for h in (hits or []):
        content = (h.get("content") or "").strip()
        title = (h.get("title") or "").strip()
        if len(content) >= 10 or len(title) >= 4:
            valid.append(h)

    if valid:
        return True, ""

    if strict_kb_enabled():
        return False, knowledge_gap_reply()

    # 未开启严格模式：仍放行，交给模型（由提示词软约束兜底）
    return True, ""
